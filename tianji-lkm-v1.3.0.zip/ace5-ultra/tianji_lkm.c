/*
 * Tianji LKM Anti-Format Kernel Module
 * Based on LANZHOUKPM-1.0, adapted for MediaTek LKM
 * Standard Linux LKM (.ko), no KPM/APatch/KernelPatch dependency
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <linux/cred.h>
#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/kprobes.h>
#include <linux/kallsyms.h>
#include <linux/blkdev.h>
#include <linux/bio.h>
#include <linux/version.h>
#include <linux/uaccess.h>
#include <linux/delay.h>
#include <linux/spinlock.h>
#include <linux/time64.h>
#include <asm/ptrace.h>
#include <asm/syscall.h>
#include <stddef.h>

#include "config_device.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("TianjiLKM");
MODULE_DESCRIPTION("Tianji LKM Anti-Format Kernel Module - 6 Layer Protection");
MODULE_VERSION("1.3.0");

/* ============================================================
 * Constants
 * ============================================================ */
#define TJ_MOD_NAME         "tianji_lkm"
#define TJ_PROC_DIR         "tianji_lkm"
#define TJ_PROC_CTRL        "ctrl"
#define TJ_PROC_STATUS      "status"

#define TJ_LOG_OFF          0
#define TJ_LOG_KEY          1
#define TJ_LOG_DEBUG        2

#define TJ_DRAIN_NS         (5ULL * NSEC_PER_SEC)
#define TJ_UNLOCK_TTL_NS    (10ULL * NSEC_PER_SEC)
#define TJ_BRUTE_WINDOW_NS  (3ULL * NSEC_PER_SEC)
#define TJ_BRUTE_THRESHOLD  3

#define TJ_CMD_BUF_SIZE     64
#define TJ_PATH_BUF_SIZE    256
#define TJ_STATUS_BUF_SIZE  512
#define TJ_WL_HASH_BITS     6
#define TJ_WL_HASH_SIZE     (1 << TJ_WL_HASH_BITS)
#define TJ_WL_HASH_MASK     (TJ_WL_HASH_SIZE - 1)

#define BIO_BDEV_OFF        offsetof(struct bio, bi_bdev)
#define BIO_OPF_OFF         offsetof(struct bio, bi_opf)
#define BDEV_PARTNO_OFF     offsetof(struct block_device, bd_partno)
#define REQ_OP_MASK         ((1 << REQ_OP_BITS) - 1)
#define REQ_OP_WRITE        1
#define REQ_OP_DISCARD      3

#define TJ_BLOCK_RET        (-EPERM)
#define TJ_BIO_STS          BLK_STS_IOERR

/* ============================================================
 * Logging
 * ============================================================ */
#define TJ_LOG(level, fmt, ...) do { \
    if (g_log_level >= (level)) \
        printk(KERN_INFO "[" TJ_MOD_NAME "] " fmt, ##__VA_ARGS__); \
} while (0)

#define TJ_ERR(fmt, ...) \
    printk(KERN_ERR "[" TJ_MOD_NAME "][ERR] " fmt, ##__VA_ARGS__)

/* ============================================================
 * Global state
 * ============================================================ */
static DEFINE_SPINLOCK(g_state_lock);

static unsigned int  g_protect_on = 0;
static unsigned long long g_unlock_at = 0;
static unsigned long long g_on_at = 0;
static unsigned long g_blocked = 0;
static unsigned long g_bio_blocked = 0;
static unsigned int  g_log_level = TJ_LOG_KEY;
static unsigned int  g_userdata_partno = TJ_USERDATA_PARTNO;

static unsigned long long g_last_unload_try = 0;
static unsigned int g_unload_try_cnt = 0;

static unsigned int g_layer_active[6] = {0};

/* ============================================================
 * Whitelist hash table (FNV-1a)
 * ============================================================ */
typedef struct wl_hash_node {
    char comm[TASK_COMM_LEN];
    unsigned int uids[4];
    struct wl_hash_node *next;
} wl_hash_node_t;

static wl_hash_node_t *g_wl_hash[TJ_WL_HASH_SIZE];

static inline unsigned int tj_wl_hash(const char *s) {
    unsigned int h = 2166136261u;
    while (*s) {
        h ^= (unsigned char)*s++;
        h *= 16777619u;
    }
    return h & TJ_WL_HASH_MASK;
}

/* Build whitelist hash table */
static int tj_wl_hash_build(void) {
    int i, cnt = 0;
    for (i = 0; i < WLCNT; i++) {
        wl_hash_node_t *node;
        unsigned int idx;
        const tj_wl_t *w = &tj_wl_table[i];

        node = kzalloc(sizeof(*node), GFP_KERNEL);
        if (!node) {
            TJ_ERR("wl hash alloc failed at %d\n", i);
            return -ENOMEM;
        }
        strscpy(node->comm, w->comm, TASK_COMM_LEN);
        memset(node->uids, 0, sizeof(node->uids));
        memcpy(node->uids, w->uids, sizeof(node->uids));
        idx = tj_wl_hash(node->comm);
        node->next = g_wl_hash[idx];
        g_wl_hash[idx] = node;
        cnt++;
    }
    TJ_LOG(TJ_LOG_KEY, "whitelist hash built: %d entries, %d buckets\n",
           cnt, TJ_WL_HASH_SIZE);
    return 0;
}

/* Destroy whitelist hash table */
static void tj_wl_hash_destroy(void) {
    int i;
    for (i = 0; i < TJ_WL_HASH_SIZE; i++) {
        wl_hash_node_t *node = g_wl_hash[i];
        while (node) {
            wl_hash_node_t *next = node->next;
            kfree(node);
            node = next;
        }
        g_wl_hash[i] = NULL;
    }
}

/* ============================================================
 * Utility functions
 * ============================================================ */

#define TJ_CFI_HASH "0f2941ad0af6714e50bee7b4b00db14e"

static void *tj_find_symbol(const char *name) {
    struct kprobe kp = { .symbol_name = name };
    char buf[128];
    int i;

    if (register_kprobe(&kp) == 0) {
        void *addr = (void *)kp.addr;
        unregister_kprobe(&kp);
        return addr;
    }

    for (i = 0; name[i]; i++) buf[i] = name[i];
    buf[i++] = '$';
    { const char *s = TJ_CFI_HASH; while (*s) buf[i++] = *s++; }
    buf[i] = 0;

    kp.symbol_name = buf;
    if (register_kprobe(&kp) == 0) {
        void *addr = (void *)kp.addr;
        unregister_kprobe(&kp);
        TJ_LOG(TJ_LOG_KEY, "CFI found: %s\n", buf);
        return addr;
    }
    return NULL;
}

static void *tj_kallsyms_lookup(const char *name) {
    return tj_find_symbol(name);
}

static void tj_panic(const char *msg) {
    TJ_ERR("PANIC: %s\n", msg);
    panic("%s", msg);
}

#define TJ_OBS_SLOTS 16
struct tj_obs_slot {
    char comm[16];
    unsigned long long last;
};
static struct tj_obs_slot g_obs[TJ_OBS_SLOTS];

static void tj_observe(const char *layer) {
    struct task_struct *t = current;
    char c[16];
    unsigned long long now, last;
    unsigned int h;
    int i, s, same;

    if (tj_task_uid(t) != 0) return;
    get_task_comm(c, t);

    now = tj_ktime();
    h = 2166136261u;
    for (i = 0; c[i]; i++) { h ^= (unsigned char)c[i]; h *= 16777619u; }
    s = h & (TJ_OBS_SLOTS - 1);

    last = g_obs[s].last;
    same = 1;
    for (i = 0; i < 16; i++) {
        if (c[i] != g_obs[s].comm[i]) { same = 0; break; }
    }
    if (same && (now - last) < 2000000000ULL) return;

    for (i = 0; i < 16; i++) g_obs[s].comm[i] = c[i];
    g_obs[s].last = now;

    TJ_LOG(TJ_LOG_KEY, "observed: %s layer=%s\n", c, layer);
}

static inline unsigned long long tj_ktime(void) {
    struct timespec64 ts;
    ktime_get_real_ts64(&ts);
    return (unsigned long long)ts.tv_sec * NSEC_PER_SEC + ts.tv_nsec;
}

static inline int tj_is_kthread(struct task_struct *t) {
    return t && t->mm == NULL;
}

static inline unsigned int tj_task_uid(struct task_struct *t) {
    const struct cred *cred;
    if (!t) return ~0u;
    cred = __task_cred(t);
    if (!cred) return ~0u;
    return from_kuid(&init_user_ns, cred->uid);
}

static inline int tj_uid_ok(const unsigned int *uids, unsigned int uid) {
    int i;
    for (i = 0; i < 4; i++) {
        if (uids[i] == 0 && i > 0) return 0;
        if (uids[i] == uid) return 1;
    }
    return 0;
}

/* ============================================================
 * Whitelist check
 * ============================================================ */
static int tj_is_sys(void) {
    struct task_struct *t = current;
    char comm[TASK_COMM_LEN];
    unsigned int uid, idx;
    wl_hash_node_t *node;

    if (unlikely(!t)) return 0;
    if (tj_is_kthread(t)) return 1;

    uid = tj_task_uid(t);
    get_task_comm(comm, t);

    idx = tj_wl_hash(comm);
    node = g_wl_hash[idx];
    while (node) {
        if (strncmp(comm, node->comm, TASK_COMM_LEN) == 0
            && tj_uid_ok(node->uids, uid)) {
            return 1;
        }
        node = node->next;
    }

    return 0;
}

/* ============================================================
 * Protection activation
 * ============================================================ */
static inline int tj_active(void) {
    unsigned long long now;
    if (!READ_ONCE(g_protect_on)) return 0;
    now = tj_ktime();
    if (READ_ONCE(g_on_at) && (now - g_on_at) < TJ_DRAIN_NS) return 0;
    return 1;
}

static inline int tj_unlocked(void) {
    unsigned long long now, d;
    unsigned long long ua = READ_ONCE(g_unlock_at);
    if (!ua) return 0;
    now = tj_ktime();
    d = now - ua;
    return d < TJ_UNLOCK_TTL_NS;
}

/* ============================================================
 * Layer 1-3: Block device hooks
 * ============================================================ */
static struct kprobe kp_blkdev_open = {
    .symbol_name = "blkdev_open",
    .pre_handler = tj_blkdev_open_pre,
};
static struct kprobe kp_blkdev_get = {
    .symbol_name = "blkdev_get",
    .pre_handler = tj_blkdev_get_pre,
};
static struct kprobe kp_blkdev_get_by_dev = {
    .symbol_name = "blkdev_get_by_dev",
    .pre_handler = tj_blkdev_get_pre,
};

/* blkdev_open: int blkdev_open(struct inode *inode, struct file *filp) */
static int tj_blkdev_open_pre(struct kprobe *p, struct pt_regs *regs) {
    struct file *file;

    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    file = (struct file *)regs->regs[1];
    if (unlikely(!file)) return 0;

    if (file->f_mode & FMODE_WRITE) {
        spin_lock(&g_state_lock);
        g_blocked++;
        spin_unlock(&g_state_lock);
        TJ_LOG(TJ_LOG_KEY, "L1 BLOCKED blkdev_open write: comm=%s\n",
               current->comm);
        regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
        regs->pc = regs->regs[30];
        return 1;
    }
    return 0;
}

/* blkdev_get / blkdev_get_by_dev:
 * int blkdev_get(struct block_device *bdev, fmode_t mode, void *hholder) */
static int tj_blkdev_get_pre(struct kprobe *p, struct pt_regs *regs) {
    fmode_t mode;

    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    mode = (fmode_t)regs->regs[1];

    if (mode & FMODE_WRITE) {
        spin_lock(&g_state_lock);
        g_blocked++;
        spin_unlock(&g_state_lock);
        TJ_LOG(TJ_LOG_KEY, "L1 BLOCKED blkdev_get write: comm=%s\n",
               current->comm);
        regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
        regs->pc = regs->regs[30];
        return 1;
    }
    return 0;
}

/* blkdev_write_iter:
 * ssize_t blkdev_write_iter(struct kiocb *iocb, struct iov_iter *from) */
static int tj_blkdev_write_pre(struct kprobe *p, struct pt_regs *regs) {
    struct kiocb *iocb;
    struct file *file;

    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    iocb = (struct kiocb *)regs->regs[0];
    if (unlikely(!iocb)) return 0;

    file = iocb->ki_filp;
    if (unlikely(!file)) return 0;

    if (file->f_mode & FMODE_WRITE) {
        spin_lock(&g_state_lock);
        g_blocked++;
        spin_unlock(&g_state_lock);
        TJ_LOG(TJ_LOG_KEY, "L2 BLOCKED blkdev_write: comm=%s\n",
               current->comm);
        regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
        regs->pc = regs->regs[30];
        return 1;
    }
    return 0;
}

/* blkdev_ioctl:
 * long blkdev_ioctl(struct file *file, unsigned int cmd, unsigned long arg) */
static int tj_blkdev_ioctl_pre(struct kprobe *p, struct pt_regs *regs) {
    struct file *file;
    unsigned int cmd;

    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    file = (struct file *)regs->regs[0];
    if (unlikely(!file)) return 0;
    cmd = (unsigned int)regs->regs[1];

    if (file->f_mode & FMODE_WRITE) {
        spin_lock(&g_state_lock);
        g_blocked++;
        spin_unlock(&g_state_lock);
        TJ_LOG(TJ_LOG_KEY, "L3 BLOCKED blkdev_ioctl cmd=0x%x: comm=%s\n",
               cmd, current->comm);
        regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
        regs->pc = regs->regs[30];
        return 1;
    }
    return 0;
}

/* ============================================================
static struct kprobe kp_blkdev_write = {
    .symbol_name = "blkdev_write_iter",
    .pre_handler = tj_blkdev_write_pre,
};
static struct kprobe kp_blkdev_ioctl = {
    .symbol_name = "blkdev_ioctl",
    .pre_handler = tj_blkdev_ioctl_pre,
};

/* ============================================================
 * Layer 4-5: Syscall hooks
 * ============================================================ */

/* openat hook */
static int tj_openat_pre(struct kprobe *p, struct pt_regs *regs) {
    const char __user *path;
    char kpath[TJ_PATH_BUF_SIZE];
    int i;

    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    path = (const char __user *)regs->regs[1];
    if (unlikely(!path)) return 0;

    if (unlikely(copy_from_user(kpath, path, sizeof(kpath) - 1)))
        return 0;
    kpath[sizeof(kpath) - 1] = '\0';

    /* Pad after NUL to prevent path bypass */
    {
        int z = 0;
        while (z < (int)sizeof(kpath) - 1 && kpath[z]) z++;
        for (; z < (int)sizeof(kpath); z++) kpath[z] = 0;
    }

    /* 检查危险路径前缀 */
    for (i = 0; i < TJ_OPEN_RULES_CNT; i++) {
        if (strncmp(kpath, tj_open_rules[i].prefix,
                    tj_open_rules[i].len) == 0) {
            spin_lock(&g_state_lock);
            g_blocked++;
            spin_unlock(&g_state_lock);
            TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED openat: %s comm=%s\n",
                   kpath, current->comm);
            /* 修改返回值为-EPERM，直接跳lr返回 */
            regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
            regs->pc = regs->regs[30];
            return 1; /* 告诉kprobe跳过原指令 */
        }
    }
    return 0;
}

/* init_module hook — 拦截非root的恶意模块加载 */
static int tj_init_module_pre(struct kprobe *p, struct pt_regs *regs) {
    unsigned int uid;

    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    uid = tj_task_uid(current);
    if (uid == 0) return 0; /* root放行 */

    spin_lock(&g_state_lock);
    g_blocked++;
    spin_unlock(&g_state_lock);
    TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED init_module (non-root uid=%u): comm=%s\n",
           uid, current->comm);
    regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
    regs->pc = regs->regs[30];
    return 1;
}

/* finit_module hook */
static int tj_finit_module_pre(struct kprobe *p, struct pt_regs *regs) {
    unsigned int uid;

    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    uid = tj_task_uid(current);
    if (uid == 0) return 0;

    spin_lock(&g_state_lock);
    g_blocked++;
    spin_unlock(&g_state_lock);
    TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED finit_module (non-root uid=%u): comm=%s\n",
           uid, current->comm);
    regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
    regs->pc = regs->regs[30];
    return 1;
}

/* kill hook — 拦截杀init进程 */
static int tj_kill_pre(struct kprobe *p, struct pt_regs *regs) {
    pid_t pid;
    int sig;

    if (unlikely(!regs)) return 0;
    pid = (pid_t)regs->regs[0];
    sig = (int)regs->regs[1];

    if (!tj_active()) return 0;
    if (pid != 1 && pid != -1) return 0;
    if (sig != SIGKILL && sig != SIGTERM && sig != SIGSTOP) return 0;
    if (tj_is_sys()) return 0;

    spin_lock(&g_state_lock);
    g_blocked++;
    spin_unlock(&g_state_lock);
    TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED kill(%d,%d): comm=%s\n",
           pid, sig, current->comm);
    regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
    regs->pc = regs->regs[30];
    return 1;
}

/* tgkill hook */
static int tj_tgkill_pre(struct kprobe *p, struct pt_regs *regs) {
    pid_t pid;
    int sig;

    if (unlikely(!regs)) return 0;
    pid = (pid_t)regs->regs[0];
    sig = (int)regs->regs[2];

    if (!tj_active()) return 0;
    if (pid != 1 && pid != -1) return 0;
    if (sig != SIGKILL && sig != SIGTERM && sig != SIGSTOP) return 0;
    if (tj_is_sys()) return 0;

    spin_lock(&g_state_lock);
    g_blocked++;
    spin_unlock(&g_state_lock);
    TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED tgkill(%d,%d): comm=%s\n",
           pid, sig, current->comm);
    regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
    regs->pc = regs->regs[30];
    return 1;
}

/* symlinkat hook — 拦截危险路径的符号链接 */
static int tj_symlinkat_pre(struct kprobe *p, struct pt_regs *regs) {
    const char __user *target;
    char ktarget[TJ_PATH_BUF_SIZE];
    int i;

    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    target = (const char __user *)regs->regs[1];
    if (unlikely(!target)) return 0;
    if (unlikely(copy_from_user(ktarget, target, sizeof(ktarget) - 1)))
        return 0;
    ktarget[sizeof(ktarget) - 1] = '\0';

    for (i = 0; i < TJ_OPEN_RULES_CNT; i++) {
        if (strncmp(ktarget, tj_open_rules[i].prefix,
                    tj_open_rules[i].len) == 0) {
            spin_lock(&g_state_lock);
            g_blocked++;
            spin_unlock(&g_state_lock);
            TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED symlinkat -> %s comm=%s\n",
                   ktarget, current->comm);
            regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
            regs->pc = regs->regs[30];
            return 1;
        }
    }
    return 0;
}

/* renameat2 hook — 拦截危险路径重命名 */
static int tj_renameat2_pre(struct kprobe *p, struct pt_regs *regs) {
    const char __user *oldpath, *newpath;
    char kpath[TJ_PATH_BUF_SIZE];
    int i;

    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    oldpath = (const char __user *)regs->regs[1];
    newpath = (const char __user *)regs->regs[3];

    if (oldpath) {
        if (unlikely(!copy_from_user(kpath, oldpath, sizeof(kpath) - 1))) {
            kpath[sizeof(kpath) - 1] = '\0';
            for (i = 0; i < TJ_OPEN_RULES_CNT; i++) {
                if (strncmp(kpath, tj_open_rules[i].prefix,
                            tj_open_rules[i].len) == 0) {
                    spin_lock(&g_state_lock);
                    g_blocked++;
                    spin_unlock(&g_state_lock);
                    TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED renameat2 old=%s comm=%s\n",
                           kpath, current->comm);
                    regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
                    regs->pc = regs->regs[30];
                    return 1;
                }
            }
        }
    }

    if (newpath) {
        if (unlikely(!copy_from_user(kpath, newpath, sizeof(kpath) - 1))) {
            kpath[sizeof(kpath) - 1] = '\0';
            for (i = 0; i < TJ_OPEN_RULES_CNT; i++) {
                if (strncmp(kpath, tj_open_rules[i].prefix,
                            tj_open_rules[i].len) == 0) {
                    spin_lock(&g_state_lock);
                    g_blocked++;
                    spin_unlock(&g_state_lock);
                    TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED renameat2 new=%s comm=%s\n",
                           kpath, current->comm);
                    regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
                    regs->pc = regs->regs[30];
                    return 1;
                }
            }
        }
    }
    return 0;
}

/* delete_module hook — 内核自保 */
static int tj_delete_module_pre(struct kprobe *p, struct pt_regs *regs) {
    unsigned long long now;
    const char __user *umodname;
    char modname[64];

    if (unlikely(!regs)) return 0;
    if (READ_ONCE(g_unloading)) return 0;
    if (tj_is_sys()) return 0;
    if (tj_unlocked()) return 0;

    umodname = (const char __user *)regs->regs[0];
    if (unlikely(!umodname)) return 0;
    if (unlikely(copy_from_user(modname, umodname, sizeof(modname) - 1)))
        return 0;
    modname[sizeof(modname) - 1] = '\0';

    if (strcmp(modname, TJ_MOD_NAME) != 0)
        return 0;

    now = tj_ktime();
    spin_lock(&g_state_lock);
    if ((now - g_last_unload_try) < TJ_BRUTE_WINDOW_NS) {
        if (++g_unload_try_cnt >= TJ_BRUTE_THRESHOLD) {
            TJ_ERR("BRUTE FORCE unload detected! comm=%s, count=%u\n",
                   current->comm, g_unload_try_cnt);
            g_unload_try_cnt = 0;
        }
    } else {
        g_unload_try_cnt = 1;
    }
    g_last_unload_try = now;
    g_blocked++;
    spin_unlock(&g_state_lock);

    TJ_LOG(TJ_LOG_KEY, "L5 BLOCKED delete_module(%s): comm=%s\n",
           modname, current->comm);
    regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
    regs->pc = regs->regs[30];
    return 1;
}

/* openat2 hook — 补充openat的绕过 */
static int tj_openat2_pre(struct kprobe *p, struct pt_regs *regs) {
    const char __user *path;
    char kpath[TJ_PATH_BUF_SIZE];
    int i;

    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    path = (const char __user *)regs->regs[1];
    if (unlikely(!path)) return 0;
    if (unlikely(copy_from_user(kpath, path, sizeof(kpath) - 1)))
        return 0;
    kpath[sizeof(kpath) - 1] = '\0';

    for (i = 0; i < TJ_OPEN_RULES_CNT; i++) {
        if (strncmp(kpath, tj_open_rules[i].prefix,
                    tj_open_rules[i].len) == 0) {
            spin_lock(&g_state_lock);
            g_blocked++;
            spin_unlock(&g_state_lock);
            TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED openat2: %s comm=%s\n",
                   kpath, current->comm);
            regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
            regs->pc = regs->regs[30];
            return 1;
        }
    }
    return 0;
}

/* symlink hook — 补充symlinkat的绕过 */
static int tj_symlink_pre(struct kprobe *p, struct pt_regs *regs) {
    const char __user *target;
    char ktarget[TJ_PATH_BUF_SIZE];
    int i;

    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    target = (const char __user *)regs->regs[0];
    if (unlikely(!target)) return 0;
    if (unlikely(copy_from_user(ktarget, target, sizeof(ktarget) - 1)))
        return 0;
    ktarget[sizeof(ktarget) - 1] = '\0';

    for (i = 0; i < TJ_OPEN_RULES_CNT; i++) {
        if (strncmp(ktarget, tj_open_rules[i].prefix,
                    tj_open_rules[i].len) == 0) {
            spin_lock(&g_state_lock);
            g_blocked++;
            spin_unlock(&g_state_lock);
            TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED symlink -> %s comm=%s\n",
                   ktarget, current->comm);
            regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
            regs->pc = regs->regs[30];
            return 1;
        }
    }
    return 0;
}

/* find_module hook — 防止攻击者查找模块 */
static int tj_find_module_pre(struct kprobe *p, struct pt_regs *regs) {
    if (unlikely(!regs)) return 0;
    if (READ_ONCE(g_unloading)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    spin_lock(&g_state_lock);
    g_blocked++;
    spin_unlock(&g_state_lock);
    tj_observe("find-module");

    regs->regs[0] = 0;
    regs->pc = regs->regs[30];
    return 1;
}

/* ============================================================
 * Layer 6: BIO bottom hook
 * ============================================================ */
static struct kprobe kp_bio_entry;
static int g_bio_hooked = 0;

static int tj_bio_pre(struct kprobe *p, struct pt_regs *regs) {
    struct bio *bio;
    struct block_device *bdev;
    unsigned int opf, partno;

    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    bio = (struct bio *)regs->regs[0];
    if (unlikely(!bio)) return 0;

    bdev = *(struct block_device **)((char *)bio + BIO_BDEV_OFF);
    if (unlikely(!bdev)) return 0;

    partno = *(unsigned int *)((char *)bdev + BDEV_PARTNO_OFF);

    if (partno > 0 && partno < (READ_ONCE(g_userdata_partno) / 2))
        return 0;

    if (partno < READ_ONCE(g_userdata_partno))
        return 0;

    opf = *(unsigned int *)((char *)bio + BIO_OPF_OFF);
    opf &= REQ_OP_MASK;

    if (opf != REQ_OP_WRITE && opf != REQ_OP_DISCARD)
        return 0;

    /* Convert write to empty read, avoid UAF */
    bio->bi_opf = (bio->bi_opf & ~REQ_OP_MASK) | REQ_OP_READ;
    bio->bi_size = 0;

    spin_lock(&g_state_lock);
    g_bio_blocked++;
    g_blocked++;
    spin_unlock(&g_state_lock);

    TJ_LOG(TJ_LOG_KEY, "L6 BLOCKED BIO: partno=%u op=%u comm=%s\n",
           partno, opf, current->comm);

    return 0;
}

/* ============================================================
 * Kprobe hooks install/remove
 * ============================================================ */
static struct kprobe kp_openat = {
    .symbol_name = "__arm64_sys_openat",
    .pre_handler = tj_openat_pre,
};
static struct kprobe kp_init_module = {
    .symbol_name = "__arm64_sys_init_module",
    .pre_handler = tj_init_module_pre,
};
static struct kprobe kp_finit_module = {
    .symbol_name = "__arm64_sys_finit_module",
    .pre_handler = tj_finit_module_pre,
};
static struct kprobe kp_delete_module = {
    .symbol_name = "__arm64_sys_delete_module",
    .pre_handler = tj_delete_module_pre,
};
static struct kprobe kp_kill = {
    .symbol_name = "__arm64_sys_kill",
    .pre_handler = tj_kill_pre,
};
static struct kprobe kp_tgkill = {
    .symbol_name = "__arm64_sys_tgkill",
    .pre_handler = tj_tgkill_pre,
};
static struct kprobe kp_symlinkat = {
    .symbol_name = "__arm64_sys_symlinkat",
    .pre_handler = tj_symlinkat_pre,
};
static struct kprobe kp_renameat2 = {
    .symbol_name = "__arm64_sys_renameat2",
    .pre_handler = tj_renameat2_pre,
};
static struct kprobe kp_openat2 = {
    .symbol_name = "__arm64_sys_openat2",
    .pre_handler = tj_openat2_pre,
};
static struct kprobe kp_symlink = {
    .symbol_name = "__arm64_sys_symlink",
    .pre_handler = tj_symlink_pre,
};
static struct kprobe kp_find_module = {
    .symbol_name = "find_module",
    .pre_handler = tj_find_module_pre,
};

static struct kprobe *g_sys_kprobes[] = {
    &kp_openat,
    &kp_init_module,
    &kp_finit_module,
    &kp_delete_module,
    &kp_kill,
    &kp_tgkill,
    &kp_symlinkat,
    &kp_renameat2,
    &kp_openat2,
    &kp_symlink,
    &kp_find_module,
};
#define SYS_KPROBE_CNT (sizeof(g_sys_kprobes)/sizeof(g_sys_kprobes[0]))

static int g_sys_kprobe_installed[SYS_KPROBE_CNT] = {0};

static int tj_install_syscall_hooks(void) {
    int i, installed = 0;

    for (i = 0; i < SYS_KPROBE_CNT; i++) {
        if (register_kprobe(g_sys_kprobes[i]) == 0) {
            g_sys_kprobe_installed[i] = 1;
            installed++;
        } else {
            TJ_LOG(TJ_LOG_KEY, "WARN: kprobe %s failed\n",
                   g_sys_kprobes[i]->symbol_name);
        }
    }

    g_layer_active[3] = (installed > 0) ? 1 : 0;
    g_layer_active[4] = g_sys_kprobe_installed[3]; /* delete_module是第5层 */

    TJ_LOG(TJ_LOG_KEY, "syscall kprobes: %d/%d installed\n",
           installed, SYS_KPROBE_CNT);
    return installed;
}

static void tj_remove_syscall_hooks(void) {
    int i;
    synchronize_rcu();
    for (i = 0; i < SYS_KPROBE_CNT; i++) {
        if (g_sys_kprobe_installed[i]) {
            unregister_kprobe(g_sys_kprobes[i]);
            g_sys_kprobe_installed[i] = 0;
        }
    }
    TJ_LOG(TJ_LOG_KEY, "syscall kprobes removed\n");
}

/* ============================================================
 * kprobe hook安装/卸载（第1-3层）
 * ============================================================ */
struct kprobe_hook {
    struct kprobe *kp;
    kprobe_pre_handler_t pre;
    const char *name;
    int layer;
};

static struct kprobe_hook g_kprobe_hooks[] = {
    { &kp_blkdev_open,       tj_blkdev_open_pre,  "blkdev_open",       1 },
    { &kp_blkdev_get,        tj_blkdev_get_pre,   "blkdev_get",        1 },
    { &kp_blkdev_get_by_dev, tj_blkdev_get_pre,   "blkdev_get_by_dev", 1 },
    { &kp_blkdev_write,      tj_blkdev_write_pre, "blkdev_write_iter", 2 },
    { &kp_blkdev_ioctl,       tj_blkdev_ioctl_pre, "blkdev_ioctl",      3 },
};
#define KPROBE_HOOK_CNT (sizeof(g_kprobe_hooks)/sizeof(g_kprobe_hooks[0]))

static int g_kprobe_installed[KPROBE_HOOK_CNT] = {0};

static int tj_install_kprobe_hooks(void) {
    int i, installed = 0;
    for (i = 0; i < KPROBE_HOOK_CNT; i++) {
        g_kprobe_hooks[i].kp->pre_handler = g_kprobe_hooks[i].pre;
        if (register_kprobe(g_kprobe_hooks[i].kp) == 0) {
            g_kprobe_installed[i] = 1;
            g_layer_active[g_kprobe_hooks[i].layer - 1] = 1;
            installed++;
            TJ_LOG(TJ_LOG_KEY, "kprobe hooked: %s (L%d)\n",
                   g_kprobe_hooks[i].name, g_kprobe_hooks[i].layer);
        } else {
            TJ_LOG(TJ_LOG_KEY, "WARN: kprobe %s failed, L%d not fully active\n",
                   g_kprobe_hooks[i].name, g_kprobe_hooks[i].layer);
        }
    }
    return installed;
}

static void tj_remove_kprobe_hooks(void) {
    int i;
    for (i = 0; i < KPROBE_HOOK_CNT; i++) {
        if (g_kprobe_installed[i]) {
            unregister_kprobe(g_kprobe_hooks[i].kp);
            g_kprobe_installed[i] = 0;
        }
    }
    TJ_LOG(TJ_LOG_KEY, "kprobe hooks removed\n");
}

/* ============================================================
 * 第六层BIO hook安装/卸载
 * ============================================================ */
static int tj_install_bio_hook(void) {
    unsigned long addr;

    /* 优先generic_make_request（5.10内核），6.6内核已移除则回退submit_bio */
    addr = (unsigned long)tj_kallsyms_lookup("generic_make_request");
    if (addr) {
        kp_bio_entry.symbol_name = "generic_make_request";
        TJ_LOG(TJ_LOG_KEY, "L6 BIO hook: generic_make_request\n");
    } else {
        addr = (unsigned long)tj_kallsyms_lookup("submit_bio");
        if (addr) {
            kp_bio_entry.symbol_name = "submit_bio";
            TJ_LOG(TJ_LOG_KEY, "L6 BIO hook: submit_bio (generic_make_request removed)\n");
        } else {
            TJ_LOG(TJ_LOG_KEY, "WARN: no BIO entry found, L6 disabled\n");
            g_layer_active[5] = 0;
            return 0;
        }
    }

    kp_bio_entry.pre_handler = tj_bio_pre;
    if (register_kprobe(&kp_bio_entry) == 0) {
        g_bio_hooked = 1;
        g_layer_active[5] = 1;
        TJ_LOG(TJ_LOG_KEY, "L6 BIO hooked OK\n");
        return 1;
    }
    TJ_LOG(TJ_LOG_KEY, "WARN: BIO kprobe failed, L6 disabled\n");
    g_layer_active[5] = 0;
    return 0;
}

static void tj_remove_bio_hook(void) {
    if (g_bio_hooked) {
        unregister_kprobe(&kp_bio_entry);
        g_bio_hooked = 0;
        g_layer_active[5] = 0;  /* 重置状态，防止/status显示造假 */
        TJ_LOG(TJ_LOG_KEY, "L6 BIO hook removed\n");
    }
}

/* ============================================================
 * procfs控制接口
 * /proc/tianji_lkm/ctrl   — 写入命令（0200，仅root可写）
 * /proc/tianji_lkm/status — 读取状态（0400，仅root可读）
 * ============================================================ */
static struct proc_dir_entry *g_proc_dir = NULL;
static struct proc_dir_entry *g_proc_ctrl = NULL;
static struct proc_dir_entry *g_proc_status = NULL;

static ssize_t tj_ctrl_write(struct file *file, const char __user *buf,
                              size_t count, loff_t *ppos) {
    char cmd[TJ_CMD_BUF_SIZE];
    int len;

    if (unlikely(!buf || count == 0)) return -EINVAL;
    if (count >= sizeof(cmd)) count = sizeof(cmd) - 1;
    if (unlikely(copy_from_user(cmd, buf, count))) return -EFAULT;
    cmd[count] = '\0';

    /* 去除尾部换行 */
    len = (int)count;
    while (len > 0 && (cmd[len - 1] == '\n' || cmd[len - 1] == '\r'))
        cmd[--len] = '\0';

    /* VT/on: 开启防护 */
    if (strcmp(cmd, "on") == 0 || strcmp(cmd, "VT") == 0) {
        spin_lock(&g_state_lock);
        g_unlock_at = 0;
        if (!g_protect_on) {
            g_on_at = tj_ktime();
            g_protect_on = 1;
        }
        spin_unlock(&g_state_lock);
        TJ_LOG(TJ_LOG_KEY, "protection ON (blocked=%lu)\n", g_blocked);
    }
    /* VD/off: 关闭防护 */
    else if (strcmp(cmd, "off") == 0 || strcmp(cmd, "VD") == 0) {
        spin_lock(&g_state_lock);
        g_unlock_at = 0;
        g_protect_on = 0;
        spin_unlock(&g_state_lock);
        TJ_LOG(TJ_LOG_KEY, "protection OFF\n");
    }
    /* VU/unlock: 解锁10秒卸载窗口 */
    else if (strcmp(cmd, "unlock") == 0 || strcmp(cmd, "VU") == 0) {
        spin_lock(&g_state_lock);
        g_unlock_at = tj_ktime();
        spin_unlock(&g_state_lock);
        TJ_LOG(TJ_LOG_KEY, "unlock 10s window\n");
    }
    /* B:1: 开启第六层BIO */
    else if (strcmp(cmd, "B:1") == 0) {
        if (!g_bio_hooked) tj_install_bio_hook();
        TJ_LOG(TJ_LOG_KEY, "BIO layer ON\n");
    }
    /* B:0: 关闭第六层BIO */
    else if (strcmp(cmd, "B:0") == 0) {
        tj_remove_bio_hook();
        TJ_LOG(TJ_LOG_KEY, "BIO layer OFF\n");
    }
    /* P:<num>: 设置userdata分区阈值 */
    else if (strncmp(cmd, "P:", 2) == 0) {
        unsigned int val = (unsigned int)simple_strtoul(cmd + 2, NULL, 10);
        if (val > 0 && val <= 255) {
            spin_lock(&g_state_lock);
            g_userdata_partno = val;
            spin_unlock(&g_state_lock);
            TJ_LOG(TJ_LOG_KEY, "userdata partno=%u\n", val);
        } else {
            TJ_LOG(TJ_LOG_KEY, "invalid partno: %s\n", cmd + 2);
        }
    }
    /* L:0/1/2: 日志级别 */
    else if (strcmp(cmd, "L:0") == 0) { g_log_level = TJ_LOG_OFF; }
    else if (strcmp(cmd, "L:1") == 0) { g_log_level = TJ_LOG_KEY; }
    else if (strcmp(cmd, "L:2") == 0) { g_log_level = TJ_LOG_DEBUG; }
    /* WL:R: 白名单热重载 */
    else if (strcmp(cmd, "WL:R") == 0) {
        tj_wl_hash_reload();
    }
    else {
        TJ_LOG(TJ_LOG_DEBUG, "unknown cmd: %s\n", cmd);
    }

    return count;
}

static ssize_t tj_status_read(struct file *file, char __user *buf,
                               size_t count, loff_t *ppos) {
    char kbuf[TJ_STATUS_BUF_SIZE];
    int len;

    if (unlikely(!buf || *ppos > 0)) return 0;

    len = snprintf(kbuf, sizeof(kbuf),
        "protect=%u\n"
        "blocked=%lu\n"
        "bio_blocked=%lu\n"
        "bio_hooked=%u\n"
        "userdata_partno=%u\n"
        "log_level=%u\n"
        "unlocked=%u\n"
        "layer1=%u\n"
        "layer2=%u\n"
        "layer3=%u\n"
        "layer4=%u\n"
        "layer5=%u\n"
        "layer6=%u\n",
        READ_ONCE(g_protect_on),
        READ_ONCE(g_blocked),
        READ_ONCE(g_bio_blocked),
        g_bio_hooked,
        READ_ONCE(g_userdata_partno),
        g_log_level,
        tj_unlocked() ? 1 : 0,
        g_layer_active[0], g_layer_active[1], g_layer_active[2],
        g_layer_active[3], g_layer_active[4], g_layer_active[5]);

    if (len < 0) return -EINVAL;
    if ((size_t)len > count) len = (int)count;
    if (unlikely(copy_to_user(buf, kbuf, len))) return -EFAULT;
    *ppos = len;
    return len;
}

static const struct proc_ops tj_ctrl_ops = {
    .proc_write = tj_ctrl_write,
};
static const struct proc_ops tj_status_ops = {
    .proc_read = tj_status_read,
};

/* ============================================================
 * 模块初始化
 * ============================================================ */
static int __init tianji_lkm_init(void) {
    int sys_cnt, kp_cnt, ret;

    TJ_LOG(TJ_LOG_OFF, "=== Tianji LKM v1.0.0 Loading ===\n");
    TJ_LOG(TJ_LOG_OFF, "Device: %s, Kernel: %s\n", TJ_DEVICE_NAME, UTS_RELEASE);

    /* 内核版本校验 */
    if (strncmp(UTS_RELEASE, TJ_KERNEL_VERSION,
                strlen(TJ_KERNEL_VERSION)) != 0) {
        TJ_ERR("kernel version mismatch! expect %s, got %s\n",
               TJ_KERNEL_VERSION, UTS_RELEASE);
        return -EINVAL;
    }

    /* 初始化全局状态 */
    spin_lock(&g_state_lock);
    g_protect_on = 0;
    g_blocked = 0;
    g_bio_blocked = 0;
    g_unloading = 0;
    g_unlock_at = 0;
    g_on_at = 0;
    g_last_unload_try = 0;
    g_unload_try_cnt = 0;
    g_userdata_partno = TJ_USERDATA_PARTNO;
    memset(g_layer_active, 0, sizeof(g_layer_active));
    spin_unlock(&g_state_lock);

    /* 构建白名单哈希表 */
    ret = tj_wl_hash_build();
    if (ret) {
        TJ_ERR("whitelist hash build failed\n");
        return ret;
    }

    /* 查找bio_endio函数地址（L6兜底用） */
    g_bio_endio_fn = tj_find_symbol("bio_endio");
    if (!g_bio_endio_fn) {
        TJ_LOG(TJ_LOG_KEY, "WARN: bio_endio not found, L6 intercept degraded\n");
    }

    /* 安装第四/五层：系统调用hook */
    sys_cnt = tj_install_syscall_hooks();
    TJ_LOG(TJ_LOG_OFF, "L4/L5 syscall hooks: %d/%d installed\n",
           sys_cnt, SYS_HOOK_CNT);

    /* 安装第一至三层：kprobe hook */
    kp_cnt = tj_install_kprobe_hooks();
    TJ_LOG(TJ_LOG_OFF, "L1-L3 kprobe hooks: %d/%d installed\n",
           kp_cnt, KPROBE_HOOK_CNT);

    /* 安装第六层：BIO hook */
    tj_install_bio_hook();

    /* 创建procfs控制接口 */
    g_proc_dir = proc_mkdir(TJ_PROC_DIR, NULL);
    if (g_proc_dir) {
        g_proc_ctrl = proc_create(TJ_PROC_CTRL, 0200, g_proc_dir, &tj_ctrl_ops);
        g_proc_status = proc_create(TJ_PROC_STATUS, 0400, g_proc_dir, &tj_status_ops);
        if (!g_proc_ctrl || !g_proc_status)
            TJ_ERR("proc_create failed\n");
    } else {
        TJ_ERR("proc_mkdir failed\n");
    }

    TJ_LOG(TJ_LOG_OFF, "=== Tianji LKM Loaded OK (awaiting activation) ===\n");
    TJ_LOG(TJ_LOG_OFF, "Layers: L1=%d L2=%d L3=%d L4=%d L5=%d L6=%d\n",
           g_layer_active[0], g_layer_active[1], g_layer_active[2],
           g_layer_active[3], g_layer_active[4], g_layer_active[5]);
    return 0;
}

/* ============================================================
 * 模块退出（完整资源清理）
 * ============================================================ */
static void __exit tianji_lkm_exit(void) {
    TJ_LOG(TJ_LOG_OFF, "=== Tianji LKM Unloading ===\n");

    /* panic卸载保护：如果没有unlock，直接panic */
    if (!tj_unlocked()) {
        tj_panic("tamper: unload without fresh unlock");
    }

    spin_lock(&g_state_lock);
    g_unloading = 1;
    g_protect_on = 0;
    g_unlock_at = 0;
    spin_unlock(&g_state_lock);

    /* 1. 移除procfs（先移除，防止卸载过程中还有写入） */
    if (g_proc_ctrl) { proc_remove(g_proc_ctrl); g_proc_ctrl = NULL; }
    if (g_proc_status) { proc_remove(g_proc_status); g_proc_status = NULL; }
    if (g_proc_dir) { proc_remove(g_proc_dir); g_proc_dir = NULL; }

    /* 2. 移除第六层BIO hook */
    tj_remove_bio_hook();

    /* 3. 移除第一至三层kprobe hook */
    tj_remove_kprobe_hooks();

    /* 4. 移除第四/五层系统调用hook */
    tj_remove_syscall_hooks();

    /* 5. 销毁白名单哈希表 */
    tj_wl_hash_destroy();

    /* 6. 校验清理状态 */
    TJ_LOG(TJ_LOG_OFF, "cleanup done\n");

    TJ_LOG(TJ_LOG_OFF, "=== Tianji LKM Unloaded (blocked=%lu, bio=%lu) ===\n",
           g_blocked, g_bio_blocked);
}

module_init(tianji_lkm_init);
module_exit(tianji_lkm_exit);
