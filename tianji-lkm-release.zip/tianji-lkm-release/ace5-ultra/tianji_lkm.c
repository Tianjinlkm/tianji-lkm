/*
 * 天玑通用LKM内核级防格机模块 - 母版 v1.1.0 (OPT)
 * 六层防护：blkdev + syscall + 内核自保 + BIO兜底
 * 标准Linux LKM (.ko)，不依赖KPM/APatch/KernelPatch框架
 * 仅需root权限 insmod/rmmod 加载卸载
 *
 * 机型配置请修改对应 config_device.h
 *
 * 优化记录 v1.1.0:
 *   - 白名单FNV-1a哈希查找，替换线性遍历
 *   - 自旋锁保护全局状态，修复竞态条件
 *   - 全链路空指针加固，防止Oops/panic
 *   - kprobe/syscall注册失败优雅降级，标记该层未启用
 *   - bio_endio函数指针缓存，避免钩子内重复kallsyms查找
 *   - 防暴力卸载检测，短时间多次rmmod触发告警
 *   - 魔术数字全部宏定义化
 *   - 模块卸载完整资源清理，无内存泄漏
 *   - 日志分级优化，正式版减少printk刷屏
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <linux/cred.h>
#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/kprobes.h>
#include <linux/kallsyms.h>
#include <linux/blkdev.h>
#include <linux/bio.h>
#include <linux/version.h>
#include <linux/uaccess.h>
#include <linux/delay.h>
#include <linux/spinlock.h>
#include <linux/time64.h>
#include <asm/ptrace.h>
#include <asm/syscall.h>

/* 引入机型配置头文件 */
#include "config_device.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("TianjiLKM");
MODULE_DESCRIPTION("Tianji LKM Anti-Format Kernel Module - 6 Layer Protection (OPT)");
MODULE_VERSION("1.1.0");

/* ============================================================
 * 宏定义统一管理（魔术数字替换）
 * ============================================================ */
#define TJ_MOD_NAME         "tianji_lkm"
#define TJ_PROC_DIR         "tianji_lkm"
#define TJ_PROC_CTRL        "ctrl"
#define TJ_PROC_STATUS      "status"

#define TJ_LOG_OFF          0
#define TJ_LOG_KEY          1
#define TJ_LOG_DEBUG        2

#define TJ_DRAIN_NS         (5ULL * NSEC_PER_SEC)
#define TJ_UNLOCK_TTL_NS    (10ULL * NSEC_PER_SEC)
#define TJ_BRUTE_WINDOW_NS  (3ULL * NSEC_PER_SEC)
#define TJ_BRUTE_THRESHOLD  3

#define TJ_CMD_BUF_SIZE     64
#define TJ_PATH_BUF_SIZE    64
#define TJ_STATUS_BUF_SIZE  512
#define TJ_WL_HASH_BITS     6
#define TJ_WL_HASH_SIZE     (1 << TJ_WL_HASH_BITS)
#define TJ_WL_HASH_MASK     (TJ_WL_HASH_SIZE - 1)

/* BIO结构体偏移（Linux 5.10/5.15/6.6 标准） */
#define BIO_BDEV_OFF        0x08
#define BIO_OPF_OFF         0x10
#define BDEV_PARTNO_OFF     0x04
#define REQ_OP_MASK         0xFF
#define REQ_OP_WRITE        1
#define REQ_OP_DISCARD      3

/* 拦截返回值 */
#define TJ_BLOCK_RET        (-EPERM)
#define TJ_BIO_STS          BLK_STS_IOERR

/* ============================================================
 * 日志宏（分级控制）
 * ============================================================ */
#define TJ_LOG(level, fmt, ...) do { \
    if (g_log_level >= (level)) \
        printk(KERN_INFO "[" TJ_MOD_NAME "] " fmt, ##__VA_ARGS__); \
} while (0)

#define TJ_ERR(fmt, ...) \
    printk(KERN_ERR "[" TJ_MOD_NAME "][ERR] " fmt, ##__VA_ARGS__)

/* ============================================================
 * 全局状态（自旋锁保护）
 * ============================================================ */
static DEFINE_SPINLOCK(g_state_lock);

static unsigned int  g_protect_on = 0;       /* 主防护开关 */
static unsigned int  g_unloading = 0;        /* 卸载标记 */
static unsigned long long g_unlock_at = 0;   /* 卸载解锁时间 */
static unsigned long long g_on_at = 0;       /* 开启时间 */
static unsigned long g_blocked = 0;          /* 总拦截计数 */
static unsigned long g_bio_blocked = 0;      /* BIO层拦截计数 */
static unsigned int  g_log_level = TJ_LOG_KEY; /* 日志级别 */
static unsigned int  g_userdata_partno = TJ_USERDATA_PARTNO; /* userdata分区阈值 */

/* 防暴力卸载 */
static unsigned long long g_last_unload_try = 0;
static unsigned int g_unload_try_cnt = 0;

/* 各层hook启用状态 */
static unsigned int g_layer_active[6] = {0};  /* 0=未启用 1=已启用 */

/* bio_endio缓存（避免钩子内重复kallsyms） */
static void (*g_bio_endio_fn)(struct bio *) = NULL;

/* ============================================================
 * 白名单哈希表（FNV-1a，O(1)查找）
 * ============================================================ */
typedef struct wl_hash_node {
    char comm[TASK_COMM_LEN];
    unsigned int uids[4];
    struct wl_hash_node *next;
} wl_hash_node_t;

static wl_hash_node_t *g_wl_hash[TJ_WL_HASH_SIZE];

/* FNV-1a 哈希 */
static inline unsigned int tj_wl_hash(const char *s) {
    unsigned int h = 2166136261u;
    while (*s) {
        h ^= (unsigned char)*s++;
        h *= 16777619u;
    }
    return h & TJ_WL_HASH_MASK;
}

/* 构建白名单哈希表 */
static int tj_wl_hash_build(void) {
    int i, cnt = 0;
    for (i = 0; i < WLCNT; i++) {
        wl_hash_node_t *node;
        unsigned int idx;
        const tj_wl_t *w = &tj_wl_table[i];

        node = kzalloc(sizeof(*node), GFP_KERNEL);
        if (!node) {
            TJ_ERR("wl hash alloc failed at %d\n", i);
            return -ENOMEM;
        }
        strscpy(node->comm, w->comm, TASK_COMM_LEN);
        memcpy(node->uids, w->uids, sizeof(node->uids));
        idx = tj_wl_hash(node->comm);
        node->next = g_wl_hash[idx];
        g_wl_hash[idx] = node;
        cnt++;
    }
    TJ_LOG(TJ_LOG_KEY, "whitelist hash built: %d entries, %d buckets\n",
           cnt, TJ_WL_HASH_SIZE);
    return 0;
}

/* 销毁白名单哈希表 */
static void tj_wl_hash_destroy(void) {
    int i;
    for (i = 0; i < TJ_WL_HASH_SIZE; i++) {
        wl_hash_node_t *node = g_wl_hash[i];
        while (node) {
            wl_hash_node_t *next = node->next;
            kfree(node);
            node = next;
        }
        g_wl_hash[i] = NULL;
    }
}

/* 白名单热重载（清空缓存标记，下次查找重建） */
static void tj_wl_hash_reload(void) {
    tj_wl_hash_destroy();
    tj_wl_hash_build();
    TJ_LOG(TJ_LOG_KEY, "whitelist hash reloaded\n");
}

/* ============================================================
 * 工具函数
 * ============================================================ */
static inline unsigned long long tj_ktime(void) {
    struct timespec64 ts;
    ktime_get_real_ts64(&ts);
    return (unsigned long long)ts.tv_sec * NSEC_PER_SEC + ts.tv_nsec;
}

static inline int tj_is_kthread(struct task_struct *t) {
    return t && t->mm == NULL;
}

static inline unsigned int tj_task_uid(struct task_struct *t) {
    const struct cred *cred;
    if (!t) return ~0u;
    cred = __task_cred(t);
    if (!cred) return ~0u;
    return from_kuid(&init_user_ns, cred->uid);
}

static inline int tj_uid_ok(const unsigned int *uids, unsigned int uid) {
    int i;
    for (i = 0; i < 4; i++)
        if (uids[i] == uid) return 1;
    return 0;
}

/* ============================================================
 * 白名单查找（哈希O(1)）
 * ============================================================ */
static int tj_is_sys(void) {
    struct task_struct *t = current;
    char comm[TASK_COMM_LEN];
    unsigned int uid, idx;
    wl_hash_node_t *node;

    if (unlikely(!t)) return 0;
    if (tj_is_kthread(t)) return 1;  /* 内核线程全部放行 */

    uid = tj_task_uid(t);
    get_task_comm(comm, t);

    /* 哈希快速匹配 */
    idx = tj_wl_hash(comm);
    node = g_wl_hash[idx];
    while (node) {
        if (strncmp(comm, node->comm, TASK_COMM_LEN) == 0
            && tj_uid_ok(node->uids, uid))
            return 1;
        node = node->next;
    }
    return 0;
}

/* ============================================================
 * 防护激活判断（5秒排水期 + 10秒卸载窗口）
 * 无锁快速路径：读全局变量，允许极小竞态窗口
 * ============================================================ */
static inline int tj_active(void) {
    unsigned long long now;
    if (!READ_ONCE(g_protect_on)) return 0;
    now = tj_ktime();
    if (READ_ONCE(g_on_at) && (now - g_on_at) < TJ_DRAIN_NS) return 0;
    return 1;
}

static inline int tj_unlocked(void) {
    unsigned long long now, d;
    unsigned long long ua = READ_ONCE(g_unlock_at);
    if (!ua) return 0;
    now = tj_ktime();
    d = now - ua;
    return d < TJ_UNLOCK_TTL_NS;
}

/* ============================================================
 * 第一层：blkdev_open / blkdev_get / blkdev_get_by_dev
 * Hook方式：kprobe pre_handler
 * ============================================================ */
static struct kprobe kp_blkdev_open = {
    .symbol_name = "blkdev_open",
};
static struct kprobe kp_blkdev_get = {
    .symbol_name = "blkdev_get",
};
static struct kprobe kp_blkdev_get_by_dev = {
    .symbol_name = "blkdev_get_by_dev",
};

/* 第1-3层通用kprobe回调 */
static int tj_blkdev_pre(struct kprobe *p, struct pt_regs *regs) {
    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    /* 拦截：x0=-1，pc=lr，直接返回不执行原函数 */
    regs->regs[0] = (unsigned long)TJ_BLOCK_RET;
    regs->pc = regs->regs[30];

    spin_lock(&g_state_lock);
    g_blocked++;
    spin_unlock(&g_state_lock);

    TJ_LOG(TJ_LOG_DEBUG, "L1-3 BLOCKED: comm=%s\n", current->comm);
    return 0;
}

/* ============================================================
 * 第二层：blkdev_write_iter — kprobe
 * 第三层：blkdev_ioctl — kprobe
 * （复用tj_blkdev_pre回调）
 * ============================================================ */
static struct kprobe kp_blkdev_write = {
    .symbol_name = "blkdev_write_iter",
    .pre_handler = tj_blkdev_pre,
};
static struct kprobe kp_blkdev_ioctl = {
    .symbol_name = "blkdev_ioctl",
    .pre_handler = tj_blkdev_pre,
};

/* ============================================================
 * 第四层：系统调用hook — sys_call_table直接替换
 * ============================================================ */
static unsigned long **g_sys_call_table = NULL;

typedef asmlinkage long (*sys_call_t)(const struct pt_regs *);
static sys_call_t orig_openat = NULL;
static sys_call_t orig_init_module = NULL;
static sys_call_t orig_finit_module = NULL;
static sys_call_t orig_delete_module = NULL;
static sys_call_t orig_kill = NULL;
static sys_call_t orig_tgkill = NULL;
static sys_call_t orig_symlinkat = NULL;
static sys_call_t orig_renameat2 = NULL;

/* ARM64内存写保护控制 */
#ifdef CONFIG_ARM64
static inline int tj_set_page_rw(unsigned long addr) {
    return set_memory_rw(PAGE_ALIGN_DOWN(addr), 1);
}
static inline int tj_set_page_ro(unsigned long addr) {
    return set_memory_ro(PAGE_ALIGN_DOWN(addr), 1);
}
#else
static unsigned long tj_cr0;
static inline void tj_write_enable(void) {
    tj_cr0 = read_cr0();
    write_cr0(tj_cr0 & ~(1UL << 16));
}
static inline void tj_write_disable(void) {
    write_cr0(tj_cr0);
}
#endif

/* openat hook — 拦截危险路径打开 */
static asmlinkage long tj_openat(const struct pt_regs *regs) {
    const char __user *path;
    char kpath[TJ_PATH_BUF_SIZE];
    int i;

    if (unlikely(!regs)) goto pass;
    if (!tj_active()) goto pass;
    if (tj_is_sys()) goto pass;

    path = (const char __user *)regs->regs[1];
    if (unlikely(!path)) goto pass;

    if (unlikely(copy_from_user(kpath, path, sizeof(kpath) - 1)))
        goto pass;
    kpath[sizeof(kpath) - 1] = '\0';

    /* 检查危险路径前缀 */
    for (i = 0; i < TJ_OPEN_RULES_CNT; i++) {
        if (strncmp(kpath, tj_open_rules[i].prefix,
                    tj_open_rules[i].len) == 0) {
            spin_lock(&g_state_lock);
            g_blocked++;
            spin_unlock(&g_state_lock);
            TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED openat: %s comm=%s\n",
                   kpath, current->comm);
            return TJ_BLOCK_RET;
        }
    }
pass:
    if (likely(orig_openat)) return orig_openat(regs);
    return -ENOSYS;
}

/* init_module hook — 拦截恶意模块加载 */
static asmlinkage long tj_init_module(const struct pt_regs *regs) {
    if (unlikely(!regs)) goto pass;
    if (!tj_active()) goto pass;
    if (tj_is_sys()) goto pass;

    spin_lock(&g_state_lock);
    g_blocked++;
    spin_unlock(&g_state_lock);
    TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED init_module: comm=%s\n", current->comm);
    return TJ_BLOCK_RET;
pass:
    if (likely(orig_init_module)) return orig_init_module(regs);
    return -ENOSYS;
}

/* finit_module hook */
static asmlinkage long tj_finit_module(const struct pt_regs *regs) {
    if (unlikely(!regs)) goto pass;
    if (!tj_active()) goto pass;
    if (tj_is_sys()) goto pass;

    spin_lock(&g_state_lock);
    g_blocked++;
    spin_unlock(&g_state_lock);
    TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED finit_module: comm=%s\n", current->comm);
    return TJ_BLOCK_RET;
pass:
    if (likely(orig_finit_module)) return orig_finit_module(regs);
    return -ENOSYS;
}

/* kill hook — 拦截杀init进程 */
static asmlinkage long tj_kill(const struct pt_regs *regs) {
    pid_t pid;
    int sig;

    if (unlikely(!regs)) goto pass;
    pid = (pid_t)regs->regs[0];
    sig = (int)regs->regs[1];

    if (!tj_active()) goto pass;
    if (pid != 1 && pid != -1) goto pass;
    if (sig != SIGKILL && sig != SIGTERM && sig != SIGSTOP) goto pass;
    if (tj_is_sys()) goto pass;

    spin_lock(&g_state_lock);
    g_blocked++;
    spin_unlock(&g_state_lock);
    TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED kill(%d,%d): comm=%s\n",
           pid, sig, current->comm);
    return TJ_BLOCK_RET;
pass:
    if (likely(orig_kill)) return orig_kill(regs);
    return -ENOSYS;
}

/* tgkill hook */
static asmlinkage long tj_tgkill(const struct pt_regs *regs) {
    pid_t pid;
    int sig;

    if (unlikely(!regs)) goto pass;
    pid = (pid_t)regs->regs[0];
    sig = (int)regs->regs[2];

    if (!tj_active()) goto pass;
    if (pid != 1 && pid != -1) goto pass;
    if (sig != SIGKILL && sig != SIGTERM && sig != SIGSTOP) goto pass;
    if (tj_is_sys()) goto pass;

    spin_lock(&g_state_lock);
    g_blocked++;
    spin_unlock(&g_state_lock);
    TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED tgkill(%d,%d): comm=%s\n",
           pid, sig, current->comm);
    return TJ_BLOCK_RET;
pass:
    if (likely(orig_tgkill)) return orig_tgkill(regs);
    return -ENOSYS;
}

/* symlinkat hook — 拦截恶意符号链接 */
static asmlinkage long tj_symlinkat(const struct pt_regs *regs) {
    if (unlikely(!regs)) goto pass;
    if (!tj_active()) goto pass;
    if (tj_is_sys()) goto pass;

    spin_lock(&g_state_lock);
    g_blocked++;
    spin_unlock(&g_state_lock);
    TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED symlinkat: comm=%s\n", current->comm);
    return TJ_BLOCK_RET;
pass:
    if (likely(orig_symlinkat)) return orig_symlinkat(regs);
    return -ENOSYS;
}

/* renameat2 hook */
static asmlinkage long tj_renameat2(const struct pt_regs *regs) {
    if (unlikely(!regs)) goto pass;
    if (!tj_active()) goto pass;
    if (tj_is_sys()) goto pass;

    spin_lock(&g_state_lock);
    g_blocked++;
    spin_unlock(&g_state_lock);
    TJ_LOG(TJ_LOG_KEY, "L4 BLOCKED renameat2: comm=%s\n", current->comm);
    return TJ_BLOCK_RET;
pass:
    if (likely(orig_renameat2)) return orig_renameat2(regs);
    return -ENOSYS;
}

/* ============================================================
 * 第五层：delete_module — 内核自保
 * 10秒卸载窗口 + 防暴力卸载检测
 * ============================================================ */
static asmlinkage long tj_delete_module(const struct pt_regs *regs) {
    unsigned long long now;

    if (unlikely(!regs)) goto pass;
    if (READ_ONCE(g_unloading)) goto pass;
    if (tj_is_sys()) goto pass;
    if (tj_unlocked()) goto pass;  /* 10秒卸载窗口内放行 */

    /* 防暴力卸载：3秒内超过3次尝试触发告警 */
    now = tj_ktime();
    spin_lock(&g_state_lock);
    if ((now - g_last_unload_try) < TJ_BRUTE_WINDOW_NS) {
        if (++g_unload_try_cnt >= TJ_BRUTE_THRESHOLD) {
            TJ_ERR("BRUTE FORCE unload detected! comm=%s, count=%u\n",
                   current->comm, g_unload_try_cnt);
            g_unload_try_cnt = 0;
        }
    } else {
        g_unload_try_cnt = 1;
    }
    g_last_unload_try = now;
    g_blocked++;
    spin_unlock(&g_state_lock);

    TJ_LOG(TJ_LOG_KEY, "L5 BLOCKED delete_module: comm=%s\n", current->comm);
    return TJ_BLOCK_RET;
pass:
    if (likely(orig_delete_module)) return orig_delete_module(regs);
    return -ENOSYS;
}

/* ============================================================
 * 第六层：BIO底层IO兜底 — generic_make_request / submit_bio
 * Hook方式：kprobe pre_handler
 * ============================================================ */
static struct kprobe kp_bio_entry;
static int g_bio_hooked = 0;

static int tj_bio_pre(struct kprobe *p, struct pt_regs *regs) {
    struct bio *bio;
    struct block_device *bdev;
    unsigned int opf, partno;

    if (unlikely(!regs)) return 0;
    if (!tj_active()) return 0;
    if (tj_is_sys()) return 0;

    /* generic_make_request/submit_bio 单参数：bio* */
    bio = (struct bio *)regs->regs[0];
    if (unlikely(!bio)) return 0;

    /* 空指针安全：读取bi_bdev */
    bdev = *(struct block_device **)((char *)bio + BIO_BDEV_OFF);
    if (unlikely(!bdev)) return 0;

    /* 读取分区号（边界校验） */
    partno = *(unsigned int *)((char *)bdev + BDEV_PARTNO_OFF);

    /* 安全锁：boot/recovery分区（分区号 < 阈值/2）自动放行 */
    if (partno > 0 && partno < (READ_ONCE(g_userdata_partno) / 2))
        return 0;

    /* 只拦截userdata分区（分区号 >= 阈值） */
    if (partno < READ_ONCE(g_userdata_partno))
        return 0;

    /* 读取bi_opf判断读写类型 */
    opf = *(unsigned int *)((char *)bio + BIO_OPF_OFF);
    opf &= REQ_OP_MASK;

    /* 只拦截WRITE和DISCARD */
    if (opf != REQ_OP_WRITE && opf != REQ_OP_DISCARD)
        return 0;

    /* 拦截计数 */
    spin_lock(&g_state_lock);
    g_bio_blocked++;
    g_blocked++;
    spin_unlock(&g_state_lock);

    TJ_LOG(TJ_LOG_DEBUG, "L6 BIO BLOCKED: partno=%u op=%u comm=%s\n",
           partno, opf, current->comm);

    /* 标记bio为错误完成，调用bio_endio，跳过原函数 */
    bio->bi_status = TJ_BIO_STS;
    if (likely(g_bio_endio_fn)) {
        g_bio_endio_fn(bio);
        regs->pc = regs->regs[30];  /* 跳转到lr，不执行原函数 */
    }
    return 0;
}

/* ============================================================
 * 系统调用表hook安装/卸载
 * ============================================================ */
struct syscall_hook {
    const char *name;
    int nr;
    sys_call_t *orig;
    sys_call_t new_fn;
    int layer;  /* 所属防护层 */
};

static struct syscall_hook g_sys_hooks[] = {
    { "__arm64_sys_openat",       __NR_openat,       &orig_openat,       tj_openat,       4 },
    { "__arm64_sys_init_module",  __NR_init_module,  &orig_init_module,  tj_init_module,  4 },
    { "__arm64_sys_finit_module", __NR_finit_module, &orig_finit_module, tj_finit_module, 4 },
    { "__arm64_sys_delete_module",__NR_delete_module,&orig_delete_module,tj_delete_module,5 },
    { "__arm64_sys_kill",         __NR_kill,         &orig_kill,         tj_kill,         4 },
    { "__arm64_sys_tgkill",       __NR_tgkill,       &orig_tgkill,       tj_tgkill,       4 },
    { "__arm64_sys_symlinkat",    __NR_symlinkat,    &orig_symlinkat,    tj_symlinkat,    4 },
    { "__arm64_sys_renameat2",    __NR_renameat2,    &orig_renameat2,    tj_renameat2,    4 },
};
#define SYS_HOOK_CNT (sizeof(g_sys_hooks)/sizeof(g_sys_hooks[0]))

static int tj_install_syscall_hooks(void) {
    int i, installed = 0;

    g_sys_call_table = (unsigned long **)kallsyms_lookup_name("sys_call_table");
    if (!g_sys_call_table) {
        TJ_ERR("sys_call_table not found, L4/L5 disabled\n");
        g_layer_active[3] = 0;  /* 第4层索引3 */
        g_layer_active[4] = 0;  /* 第5层索引4 */
        return -1;
    }
    TJ_LOG(TJ_LOG_KEY, "sys_call_table at %px\n", g_sys_call_table);

#ifdef CONFIG_ARM64
    if (tj_set_page_rw((unsigned long)g_sys_call_table) != 0) {
        TJ_ERR("set_memory_rw failed\n");
        return -1;
    }
#else
    tj_write_enable();
#endif

    for (i = 0; i < SYS_HOOK_CNT; i++) {
        unsigned long sym = kallsyms_lookup_name(g_sys_hooks[i].name);
        if (!sym) {
            TJ_LOG(TJ_LOG_KEY, "WARN: %s not found, this syscall not hooked\n",
                   g_sys_hooks[i].name);
            continue;
        }
        *g_sys_hooks[i].orig = (sys_call_t)g_sys_call_table[g_sys_hooks[i].nr];
        g_sys_call_table[g_sys_hooks[i].nr] =
            (unsigned long *)g_sys_hooks[i].new_fn;
        g_layer_active[g_sys_hooks[i].layer - 1] = 1;
        installed++;
        TJ_LOG(TJ_LOG_KEY, "hooked syscall %s (nr=%d, L%d)\n",
               g_sys_hooks[i].name, g_sys_hooks[i].nr,
               g_sys_hooks[i].layer);
    }

#ifdef CONFIG_ARM64
    tj_set_page_ro((unsigned long)g_sys_call_table);
#else
    tj_write_disable();
#endif

    return installed;
}

static void tj_remove_syscall_hooks(void) {
    int i;
    if (!g_sys_call_table) return;

#ifdef CONFIG_ARM64
    tj_set_page_rw((unsigned long)g_sys_call_table);
#else
    tj_write_enable();
#endif

    for (i = 0; i < SYS_HOOK_CNT; i++) {
        if (*g_sys_hooks[i].orig) {
            g_sys_call_table[g_sys_hooks[i].nr] =
                (unsigned long *)*g_sys_hooks[i].orig;
            *g_sys_hooks[i].orig = NULL;
        }
    }

#ifdef CONFIG_ARM64
    tj_set_page_ro((unsigned long)g_sys_call_table);
#else
    tj_write_disable();
#endif
    TJ_LOG(TJ_LOG_KEY, "syscall hooks removed\n");
}

/* ============================================================
 * kprobe hook安装/卸载（第1-3层）
 * ============================================================ */
struct kprobe_hook {
    struct kprobe *kp;
    kprobe_pre_handler_t pre;
    const char *name;
    int layer;
};

static struct kprobe_hook g_kprobe_hooks[] = {
    { &kp_blkdev_open,       tj_blkdev_pre, "blkdev_open",       1 },
    { &kp_blkdev_get,        tj_blkdev_pre, "blkdev_get",        1 },
    { &kp_blkdev_get_by_dev, tj_blkdev_pre, "blkdev_get_by_dev", 1 },
    { &kp_blkdev_write,      tj_blkdev_pre, "blkdev_write_iter", 2 },
    { &kp_blkdev_ioctl,      tj_blkdev_pre, "blkdev_ioctl",      3 },
};
#define KPROBE_HOOK_CNT (sizeof(g_kprobe_hooks)/sizeof(g_kprobe_hooks[0]))

static int g_kprobe_installed[KPROBE_HOOK_CNT] = {0};

static int tj_install_kprobe_hooks(void) {
    int i, installed = 0;
    for (i = 0; i < KPROBE_HOOK_CNT; i++) {
        g_kprobe_hooks[i].kp->pre_handler = g_kprobe_hooks[i].pre;
        if (register_kprobe(g_kprobe_hooks[i].kp) == 0) {
            g_kprobe_installed[i] = 1;
            g_layer_active[g_kprobe_hooks[i].layer - 1] = 1;
            installed++;
            TJ_LOG(TJ_LOG_KEY, "kprobe hooked: %s (L%d)\n",
                   g_kprobe_hooks[i].name, g_kprobe_hooks[i].layer);
        } else {
            TJ_LOG(TJ_LOG_KEY, "WARN: kprobe %s failed, L%d not fully active\n",
                   g_kprobe_hooks[i].name, g_kprobe_hooks[i].layer);
        }
    }
    return installed;
}

static void tj_remove_kprobe_hooks(void) {
    int i;
    for (i = 0; i < KPROBE_HOOK_CNT; i++) {
        if (g_kprobe_installed[i]) {
            unregister_kprobe(g_kprobe_hooks[i].kp);
            g_kprobe_installed[i] = 0;
        }
    }
    TJ_LOG(TJ_LOG_KEY, "kprobe hooks removed\n");
}

/* ============================================================
 * 第六层BIO hook安装/卸载
 * ============================================================ */
static int tj_install_bio_hook(void) {
    unsigned long addr;

    /* 优先generic_make_request（5.10内核），6.6内核已移除则回退submit_bio */
    addr = kallsyms_lookup_name("generic_make_request");
    if (addr) {
        kp_bio_entry.symbol_name = "generic_make_request";
        TJ_LOG(TJ_LOG_KEY, "L6 BIO hook: generic_make_request\n");
    } else {
        addr = kallsyms_lookup_name("submit_bio");
        if (addr) {
            kp_bio_entry.symbol_name = "submit_bio";
            TJ_LOG(TJ_LOG_KEY, "L6 BIO hook: submit_bio (generic_make_request removed)\n");
        } else {
            TJ_LOG(TJ_LOG_KEY, "WARN: no BIO entry found, L6 disabled\n");
            g_layer_active[5] = 0;
            return 0;
        }
    }

    kp_bio_entry.pre_handler = tj_bio_pre;
    if (register_kprobe(&kp_bio_entry) == 0) {
        g_bio_hooked = 1;
        g_layer_active[5] = 1;
        TJ_LOG(TJ_LOG_KEY, "L6 BIO hooked OK\n");
        return 1;
    }
    TJ_LOG(TJ_LOG_KEY, "WARN: BIO kprobe failed, L6 disabled\n");
    g_layer_active[5] = 0;
    return 0;
}

static void tj_remove_bio_hook(void) {
    if (g_bio_hooked) {
        unregister_kprobe(&kp_bio_entry);
        g_bio_hooked = 0;
        TJ_LOG(TJ_LOG_KEY, "L6 BIO hook removed\n");
    }
}

/* ============================================================
 * procfs控制接口
 * /proc/tianji_lkm/ctrl   — 写入命令（0200，仅root可写）
 * /proc/tianji_lkm/status — 读取状态（0400，仅root可读）
 * ============================================================ */
static struct proc_dir_entry *g_proc_dir = NULL;
static struct proc_dir_entry *g_proc_ctrl = NULL;
static struct proc_dir_entry *g_proc_status = NULL;

static ssize_t tj_ctrl_write(struct file *file, const char __user *buf,
                              size_t count, loff_t *ppos) {
    char cmd[TJ_CMD_BUF_SIZE];
    int len;

    if (unlikely(!buf || count == 0)) return -EINVAL;
    if (count >= sizeof(cmd)) count = sizeof(cmd) - 1;
    if (unlikely(copy_from_user(cmd, buf, count))) return -EFAULT;
    cmd[count] = '\0';

    /* 去除尾部换行 */
    len = (int)count;
    while (len > 0 && (cmd[len - 1] == '\n' || cmd[len - 1] == '\r'))
        cmd[--len] = '\0';

    /* VT/on: 开启防护 */
    if (strcmp(cmd, "on") == 0 || strcmp(cmd, "VT") == 0) {
        spin_lock(&g_state_lock);
        g_unlock_at = 0;
        if (!g_protect_on) {
            g_on_at = tj_ktime();
            g_protect_on = 1;
        }
        spin_unlock(&g_state_lock);
        TJ_LOG(TJ_LOG_KEY, "protection ON (blocked=%lu)\n", g_blocked);
    }
    /* VD/off: 关闭防护 */
    else if (strcmp(cmd, "off") == 0 || strcmp(cmd, "VD") == 0) {
        spin_lock(&g_state_lock);
        g_unlock_at = 0;
        g_protect_on = 0;
        spin_unlock(&g_state_lock);
        TJ_LOG(TJ_LOG_KEY, "protection OFF\n");
    }
    /* VU/unlock: 解锁10秒卸载窗口 */
    else if (strcmp(cmd, "unlock") == 0 || strcmp(cmd, "VU") == 0) {
        spin_lock(&g_state_lock);
        g_unlock_at = tj_ktime();
        spin_unlock(&g_state_lock);
        TJ_LOG(TJ_LOG_KEY, "unlock 10s window\n");
    }
    /* B:1: 开启第六层BIO */
    else if (strcmp(cmd, "B:1") == 0) {
        if (!g_bio_hooked) tj_install_bio_hook();
        TJ_LOG(TJ_LOG_KEY, "BIO layer ON\n");
    }
    /* B:0: 关闭第六层BIO */
    else if (strcmp(cmd, "B:0") == 0) {
        tj_remove_bio_hook();
        TJ_LOG(TJ_LOG_KEY, "BIO layer OFF\n");
    }
    /* P:<num>: 设置userdata分区阈值 */
    else if (strncmp(cmd, "P:", 2) == 0) {
        unsigned int val = (unsigned int)simple_strtoul(cmd + 2, NULL, 10);
        if (val > 0 && val <= 255) {
            spin_lock(&g_state_lock);
            g_userdata_partno = val;
            spin_unlock(&g_state_lock);
            TJ_LOG(TJ_LOG_KEY, "userdata partno=%u\n", val);
        } else {
            TJ_LOG(TJ_LOG_KEY, "invalid partno: %s\n", cmd + 2);
        }
    }
    /* L:0/1/2: 日志级别 */
    else if (strcmp(cmd, "L:0") == 0) { g_log_level = TJ_LOG_OFF; }
    else if (strcmp(cmd, "L:1") == 0) { g_log_level = TJ_LOG_KEY; }
    else if (strcmp(cmd, "L:2") == 0) { g_log_level = TJ_LOG_DEBUG; }
    /* WL:R: 白名单热重载 */
    else if (strcmp(cmd, "WL:R") == 0) {
        tj_wl_hash_reload();
    }
    else {
        TJ_LOG(TJ_LOG_DEBUG, "unknown cmd: %s\n", cmd);
    }

    return count;
}

static ssize_t tj_status_read(struct file *file, char __user *buf,
                               size_t count, loff_t *ppos) {
    char kbuf[TJ_STATUS_BUF_SIZE];
    int len;

    if (unlikely(!buf || *ppos > 0)) return 0;

    len = snprintf(kbuf, sizeof(kbuf),
        "protect=%u\n"
        "blocked=%lu\n"
        "bio_blocked=%lu\n"
        "bio_hooked=%u\n"
        "userdata_partno=%u\n"
        "log_level=%u\n"
        "unlocked=%u\n"
        "layer1=%u\n"
        "layer2=%u\n"
        "layer3=%u\n"
        "layer4=%u\n"
        "layer5=%u\n"
        "layer6=%u\n",
        READ_ONCE(g_protect_on),
        READ_ONCE(g_blocked),
        READ_ONCE(g_bio_blocked),
        g_bio_hooked,
        READ_ONCE(g_userdata_partno),
        g_log_level,
        tj_unlocked() ? 1 : 0,
        g_layer_active[0], g_layer_active[1], g_layer_active[2],
        g_layer_active[3], g_layer_active[4], g_layer_active[5]);

    if (len < 0) return -EINVAL;
    if ((size_t)len > count) len = (int)count;
    if (unlikely(copy_to_user(buf, kbuf, len))) return -EFAULT;
    *ppos = len;
    return len;
}

static const struct proc_ops tj_ctrl_ops = {
    .proc_write = tj_ctrl_write,
};
static const struct proc_ops tj_status_ops = {
    .proc_read = tj_status_read,
};

/* ============================================================
 * 模块初始化
 * ============================================================ */
static int __init tianji_lkm_init(void) {
    int sys_cnt, kp_cnt, ret;

    TJ_LOG(TJ_LOG_OFF, "=== Tianji LKM v1.1.0 (OPT) Loading ===\n");
    TJ_LOG(TJ_LOG_OFF, "Device: %s, Kernel: %s\n", TJ_DEVICE_NAME, UTS_RELEASE);

    /* 内核版本校验 */
    if (strncmp(UTS_RELEASE, TJ_KERNEL_VERSION,
                strlen(TJ_KERNEL_VERSION)) != 0) {
        TJ_ERR("kernel version mismatch! expect %s, got %s\n",
               TJ_KERNEL_VERSION, UTS_RELEASE);
        return -EINVAL;
    }

    /* 初始化全局状态 */
    spin_lock(&g_state_lock);
    g_protect_on = 0;
    g_blocked = 0;
    g_bio_blocked = 0;
    g_unloading = 0;
    g_unlock_at = 0;
    g_on_at = 0;
    g_last_unload_try = 0;
    g_unload_try_cnt = 0;
    g_userdata_partno = TJ_USERDATA_PARTNO;
    memset(g_layer_active, 0, sizeof(g_layer_active));
    spin_unlock(&g_state_lock);

    /* 构建白名单哈希表 */
    ret = tj_wl_hash_build();
    if (ret) {
        TJ_ERR("whitelist hash build failed\n");
        return ret;
    }

    /* 缓存bio_endio函数指针 */
    g_bio_endio_fn = (void (*)(struct bio *))kallsyms_lookup_name("bio_endio");
    if (!g_bio_endio_fn)
        TJ_LOG(TJ_LOG_KEY, "WARN: bio_endio not found, L6 intercept degraded\n");

    /* 安装第四/五层：系统调用hook */
    sys_cnt = tj_install_syscall_hooks();
    TJ_LOG(TJ_LOG_OFF, "L4/L5 syscall hooks: %d/%d installed\n",
           sys_cnt, SYS_HOOK_CNT);

    /* 安装第一至三层：kprobe hook */
    kp_cnt = tj_install_kprobe_hooks();
    TJ_LOG(TJ_LOG_OFF, "L1-L3 kprobe hooks: %d/%d installed\n",
           kp_cnt, KPROBE_HOOK_CNT);

    /* 安装第六层：BIO hook */
    tj_install_bio_hook();

    /* 创建procfs控制接口 */
    g_proc_dir = proc_mkdir(TJ_PROC_DIR, NULL);
    if (g_proc_dir) {
        g_proc_ctrl = proc_create(TJ_PROC_CTRL, 0200, g_proc_dir, &tj_ctrl_ops);
        g_proc_status = proc_create(TJ_PROC_STATUS, 0400, g_proc_dir, &tj_status_ops);
        if (!g_proc_ctrl || !g_proc_status)
            TJ_ERR("proc_create failed\n");
    } else {
        TJ_ERR("proc_mkdir failed\n");
    }

    TJ_LOG(TJ_LOG_OFF, "=== Tianji LKM Loaded OK (awaiting activation) ===\n");
    TJ_LOG(TJ_LOG_OFF, "Layers: L1=%d L2=%d L3=%d L4=%d L5=%d L6=%d\n",
           g_layer_active[0], g_layer_active[1], g_layer_active[2],
           g_layer_active[3], g_layer_active[4], g_layer_active[5]);
    return 0;
}

/* ============================================================
 * 模块退出（完整资源清理）
 * ============================================================ */
static void __exit tianji_lkm_exit(void) {
    TJ_LOG(TJ_LOG_OFF, "=== Tianji LKM Unloading ===\n");

    spin_lock(&g_state_lock);
    g_unloading = 1;
    g_protect_on = 0;
    g_unlock_at = tj_ktime();  /* 解锁卸载窗口 */
    spin_unlock(&g_state_lock);

    /* 1. 移除procfs（先移除，防止卸载过程中还有写入） */
    if (g_proc_ctrl) { proc_remove(g_proc_ctrl); g_proc_ctrl = NULL; }
    if (g_proc_status) { proc_remove(g_proc_status); g_proc_status = NULL; }
    if (g_proc_dir) { proc_remove(g_proc_dir); g_proc_dir = NULL; }

    /* 2. 移除第六层BIO hook */
    tj_remove_bio_hook();

    /* 3. 移除第一至三层kprobe hook */
    tj_remove_kprobe_hooks();

    /* 4. 移除第四/五层系统调用hook */
    tj_remove_syscall_hooks();

    /* 5. 销毁白名单哈希表 */
    tj_wl_hash_destroy();

    /* 6. 校验清理状态 */
    TJ_LOG(TJ_LOG_OFF, "cleanup: sys_call_table=%pK bio_endio=%pK\n",
           g_sys_call_table, g_bio_endio_fn);
    g_sys_call_table = NULL;
    g_bio_endio_fn = NULL;

    TJ_LOG(TJ_LOG_OFF, "=== Tianji LKM Unloaded (blocked=%lu, bio=%lu) ===\n",
           g_blocked, g_bio_blocked);
}

module_init(tianji_lkm_init);
module_exit(tianji_lkm_exit);
