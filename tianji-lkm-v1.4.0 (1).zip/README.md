# Tianji LKM — 天玑通用内核级防格机模块

基于 Linux LKM (.ko) 的内核级防恶意格机保护模块，六层防护，拦截天玑平台恶意格机脚本。

> 基于蓝昼 LANZHOUKPM-1.0 二次开发，由 KPM 迁移至原生 LKM，遵循 GPL-2.0 协议开源。

## 目录结构

```
tianji-lkm-release/
├── ace5-ultra/          # 一加 Ace5 至尊版（ColorOS 16 / Linux 6.6）
│   ├── tianji_lkm.c
│   ├── config_device.h
│   └── Makefile
├── k60e/                # 红米 K60E（MIUI 14.0.6 / Linux 5.10）
│   ├── tianji_lkm.c
│   ├── config_device.h
│   ├── tianji_console.sh
│   └── Makefile
├── README.md
└── LICENSE
```

## 适配机型

| 机型 | 系统 | 内核 | SoC | 版本 |
|------|------|------|-----|------|
| OnePlus Ace5 Ultra | ColorOS 16.0.10.500 | Linux 6.6.x | 天玑9400+ | v1.1.0 |
| Redmi K60E | MIUI 14.0.6 | Linux 5.10.x | 天玑8200 | v1.1.1 |

## 六层防护

L1 blkdev_open/get → L2 blkdev_write_iter → L3 blkdev_ioctl → L4 sys_call_table → L5 delete_module 自保 → L6 BIO 底层兜底

## 致谢

- 蓝昼 — 原始 KPM 防格思路与源码（LANZHOUKPM-1.0）

## License

GPL-2.0-or-later，详见 LICENSE。
