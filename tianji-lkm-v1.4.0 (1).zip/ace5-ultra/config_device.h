/*
 * 一加Ace5至尊版 机型配置头文件
 * Device: OnePlus Ace5 Ultra / 至尊版 (codename: prosper)
 * SoC: MediaTek 天玑9400+ (MT6989)
 * OS: ColorOS 16 PC.LC.L0.16.0.10.500
 * Kernel: Linux 6.6.x (Android 15)
 * Arch: ARM64
 *
 * 适配其他天玑机型时，仅需替换此文件，无需修改tianji_lkm.c母版
 */

#ifndef CONFIG_DEVICE_H
#define CONFIG_DEVICE_H

/* ============================================================
 * 设备基本信息
 * ============================================================ */
#define TJ_DEVICE_NAME      "OnePlus Ace5 Ultra"
#define TJ_DEVICE_CODENAME  "prosper"
#define TJ_SOC_NAME         "MediaTek Dimensity 9400+ (MT6989)"
#define TJ_KERNEL_VERSION   "6.6"    /* 内核版本前缀校验，insmod时验证 */

/* ============================================================
 * userdata分区阈值
 * UFS设备：userdata通常是sda30+，阈值设为30
 * 安全锁：分区号 < 阈值/2 时判定为boot/recovery分区，自动放行
 * ============================================================ */
#define TJ_USERDATA_PARTNO  30

/* ============================================================
 * 白名单进程表
 * comm: 进程名（task_struct->comm，最多15字符）
 * exe_base: 可执行文件名（预留双重校验）
 * uids: 允许的UID数组（4个，0结尾表示不限）
 *
 * 白名单进程发起的块设备操作和BIO IO全部放行
 * 非白名单进程的恶意操作将被拦截
 * ============================================================ */
typedef struct {
    const char *comm;
    const char *exe_base;   /* 可执行文件名（预留双重校验） */
    const unsigned int uids[4];
} tj_wl_t;

static const tj_wl_t tj_wl_table[] = {
    /* === 核心init族 === */
    {"init",              "init",              {0}},
    {"ueventd",           "init",              {0}},

    /* === 存储/文件系统 === */
    {"vold",              "vold",              {0}},
    {"storaged",          "storaged",          {0}},
    {"lmkd",              "lmkd",              {1067}},
    {"installd",          "installd",          {0}},
    {"keystore",          "keystore",          {0}},
    {"gatekeeperd",       "gatekeeperd",       {0}},

    /* === 网络 === */
    {"netd",              "netd",              {0}},
    {"rild",              "rild",              {1001}},

    /* === 天玑MTK基带/平台专属 === */
    {"ccci_mdinit",       "ccci_mdinit",       {0, 1001}},
    {"ccci_mdinit1",      "ccci_mdinit1",      {0, 1001}},
    {"ccci_mdinit2",      "ccci_mdinit2",      {0, 1001}},
    {"ccci_mdinit_d",     "ccci_mdinit_d",     {0, 1001}},
    {"mtk_daemon",        "mtk_daemon",        {0, 1000}},
    {"mtk_hal_daemon",    "mtk_hal_daemon",    {0, 1000}},
    {"agps_mtk",          "agps_mtk",          {0, 1000, 1001}},
    {"gps_mtk",           "gps_mtk",           {0, 1000, 1001}},
    {"nvram_daemon",      "nvram_daemon",      {0, 1000}},
    {"emcsmd",            "emcsmd",            {0, 1001}},
    {"fota",              "fota",              {0, 1000}},
    {"meta_tst",          "meta_tst",          {0, 1000}},
    {"matv",              "matv",              {0, 1000}},

    /* === OPPO/一加专属 === */
    {"oppo.ril",          "oppo.ril",          {0, 1001}},
    {"oemlogkit",         "oemlogkit",         {0, 1000}},
    {"oppo.thermal",      "oppo.thermal",      {0}},
    {"thermal-engine",    "thermal-engine",    {0}},
    {"watchdogd",         "watchdogd",         {0}},
    {"kblockd",           "kblockd",           {0}},

    /* === 系统服务 === */
    {"audioserver",       "audioserver",       {1041}},
    {"mediaserver",       "mediaserver",       {1013}},
    {"cameraserver",     "cameraserver",      {1047}},
    {"drmserver",         "drmserver",         {1019}},
    {"bufferextract",     "bufferextract",     {0}},
    {"tombstoned",        "tombstoned",        {0}},
    {"statsd",            "statsd",            {0}},
    {"perfetto",          "perfetto",          {0}},
    {"traced",            "traced",            {0}},
    {"incidentd",         "incidentd",         {0}},
    {"dumpstate",         "dumpstate",         {0}},
    {"logd",              "logd",              {0}},
    {"adbd",              "adbd",              {0}},
    {"debuggerd",         "debuggerd",         {0}},
    {"healthd",           "healthd",           {0}},
    {"zygote",            "zygote",            {0}},
    {"zygote64",          "zygote64",          {0}},
    {"system_server",     "system_server",     {1000}},
    {"surfaceflinger",    "surfaceflinger",     {1018}},
    {"servicemanager",    "servicemanager",    {0}},
    {"hwservicemanager",  "hwservicemanager",  {0}},

    /* === 恢复/引导 === */
    {"recovery",          "recovery",          {0}},
    {"fastboot",          "fastboot",          {0}},
    {"install_recovery",  "install_recovery",  {0}},

    /* === MTK HAL服务 === */
    {"vendor.mediatek.hardware.mtkpower@1.0-service", "vendor.mediatek.hardware.mtkpower@1.0-service", {0}},
    {"vendor.mediatek.hardware.power@2.0-service", "vendor.mediatek.hardware.power@2.0-service", {0}},
    {"android.hardware.thermal@2.0-service.mediatek", "android.hardware.thermal@2.0-service.mediatek", {0}},
    {"vendor.mediatek.hardware.audio@4.0-service", "vendor.mediatek.hardware.audio@4.0-service", {0}},
};

#define WLCNT (sizeof(tj_wl_table)/sizeof(tj_wl_table[0]))

/* ============================================================
 * openat危险路径前缀规则
 * 非白名单进程打开这些路径时直接拦截
 * ============================================================ */
typedef struct {
    const char *prefix;
    unsigned char len;
} tj_open_rule_t;

static const tj_open_rule_t tj_open_rules[] = {
    {"/dev/block",           10},
    {"/dev/ufs-bsg",         12},
    {"/dev/bsg",              8},
    {"/dev/sg",               7},
    {"/proc/sysrq-trigger",  20},
    {"/config/usb",          11},
    {"/dev/socket/props",    16},
    {"/data/adb/modules",    18},
    {"/data/adb/kpatch",     16},
    {"/data/adb/service.d",  20},
    {"/data/adb/post-fs-data", 25},
};
#define TJ_OPEN_RULES_CNT (sizeof(tj_open_rules)/sizeof(tj_open_rules[0]))

#endif /* CONFIG_DEVICE_H */
