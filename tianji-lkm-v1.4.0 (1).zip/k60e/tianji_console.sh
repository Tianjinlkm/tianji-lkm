﻿#!/system/bin/sh
# ============================================================
# 天玑LKM防格机控制台 - 红米K60E
# MIUI14.0.6 / 天玑8200 / Linux 5.10
# ============================================================

MOD="tianji_lkm"
KOPATH="/data/local/tmp/${MOD}.ko"
PROCDIR="/proc/${MOD}"
CTRL="${PROCDIR}/ctrl"
STAT="${PROCDIR}/status"
TARGET_OS="16"
TARGET_COLOROS="PC.LC.L0.16"

# 颜色
R='\033[0;31m'
G='\033[0;32m'
Y='\033[1;33m'
C='\033[0;36m'
N='\033[0m'

# 混淆工具函数
_l() { echo "$1"; }
_s() { printf "%s" "$1"; }

banner() {
echo ""
echo " ████████╗██╗ █████╗ ███╗   ██╗     ██╗██╗  ██╗███╗   ███╗"
echo " ╚══██╔══╝██║██╔══██╗████╗  ██║     ██║██║ ██╔╝████╗ ████║"
echo "    ██║   ██║███████║██╔██╗ ██║     ██║█████╔╝ ██╔████╔██║"
echo "    ██║   ██║██╔══██║██║╚██╗██║██   ██║██╔═██╗ ██║╚██╔╝██║"
echo "    ██║   ██║██║  ██║██║ ╚████║╚█████╔╝██║  ██╗██║ ╚═╝ ██║"
echo "    ╚═╝   ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝ ╚════╝ ╚═╝  ╚═╝╚═╝     ╚═╝"
echo ""
echo "   红米K60E · MIUI14.0.6 · 天玑8200 · Linux 5.10"
echo "   六层防护 LKM内核模块 · v1.1.0 (K60E)"
echo ""
}

# 版本预检
check_ver() {
    local sdk=$(getprop ro.build.version.sdk 2>/dev/null)
    local cos=$(getprop ro.build.version.oplusrom 2>/dev/null)
    local color=$(getprop ro.build.version.release 2>/dev/null)
    echo "[i] Android SDK: $sdk | ColorOS: $cos | OS: $color"
    if [ -n "$sdk" ] && [ "$sdk" -ge 35 ]; then
        echo -e "${G}[+] Android 15+ 检测通过${N}"
    else
        echo -e "${Y}[-] 非Android 15，可能不兼容${N}"
    fi
}

# 检查root
check_root() {
    if [ "$(id -u)" != "0" ]; then
        echo -e "${R}[!] 需要root权限！请用 su 执行${N}"
        return 1
    fi
    return 0
}

# 检查模块是否加载
is_loaded() {
    lsmod 2>/dev/null | grep -q "^${MOD}"
}

# 加载模块
load_mod() {
    check_root || return 1
    if is_loaded; then
        echo -e "${Y}[-] 模块已加载${N}"
        return 0
    fi
    if [ ! -f "$KOPATH" ]; then
        echo -e "${R}[!] 找不到 $KOPATH${N}"
        echo "[i] 请先将 ${MOD}.ko 推送到 /data/local/tmp/"
        return 1
    fi
    echo "[+] 正在加载内核模块..."
    insmod "$KOPATH" 2>&1
    if [ $? -eq 0 ]; then
        sleep 1
        if is_loaded; then
            echo -e "${G}[+] 模块加载成功${N}"
            echo "[+] 控制接口: $PROCDIR"
            return 0
        fi
    fi
    echo -e "${R}[!] 加载失败，请检查内核版本是否匹配${N}"
    dmesg | tail -20 | grep -i "tianji\|error\|fail"
    return 1
}

# 卸载模块
unload_mod() {
    check_root || return 1
    is_loaded || { echo -e "${Y}[-] 模块未加载${N}"; return 0; }
    echo "[!] 解锁10秒卸载窗口..."
    echo "unlock" > "$CTRL" 2>/dev/null
    sleep 1
    echo "[+] 正在卸载..."
    rmmod "$MOD" 2>&1
    if [ $? -eq 0 ]; then
        echo -e "${G}[+] 模块已卸载${N}"
    else
        echo -e "${R}[!] 卸载失败${N}"
    fi
}

# 开启防护
protect_on() {
    check_root || return 1
    is_loaded || { echo -e "${R}[!] 请先加载模块${N}"; return 1; }
    echo "on" > "$CTRL"
    echo "B:1" > "$CTRL" 2>/dev/null
    sleep 1
    echo -e "${G}[+] 全部防护已开启（含BIO第六层）${N}"
}

# 关闭防护
protect_off() {
    check_root || return 1
    is_loaded || { echo -e "${R}[!] 模块未加载${N}"; return 1; }
    echo "off" > "$CTRL"
    echo "B:0" > "$CTRL" 2>/dev/null
    echo -e "${Y}[-] 防护已关闭${N}"
}

# 查看状态
show_status() {
    echo ""
    echo "===== 防护状态 ====="
    if ! is_loaded; then
        echo -e "${R}模块未加载${N}"
        return
    fi
    echo -e "模块: ${G}已加载${N}"
    local l1=0 l2=0 l3=0 l4=0 l5=0 l6=0
    cat "$STAT" 2>/dev/null | while read line; do
        key=$(echo "$line" | cut -d= -f1)
        val=$(echo "$line" | cut -d= -f2)
        case "$key" in
            protect) [ "$val" = "1" ] && echo -e "主防护: ${G}开启${N}" || echo -e "主防护: ${Y}关闭${N}" ;;
            blocked) echo "总拦截计数: $val 次" ;;
            bio_blocked) echo "BIO层拦截: $val 次" ;;
            bio_hooked) [ "$val" = "1" ] && echo -e "BIO第六层: ${G}已挂载${N}" || echo -e "BIO第六层: ${Y}未挂载${N}" ;;
            userdata_partno) echo "userdata分区阈值: $val" ;;
            log_level) echo "日志级别: $val" ;;
            unlocked) [ "$val" = "1" ] && echo -e "卸载窗口: ${G}已解锁${N}" || echo "卸载窗口: 锁定" ;;
            layer1) l1=$val ;;
            layer2) l2=$val ;;
            layer3) l3=$val ;;
            layer4) l4=$val ;;
            layer5) l5=$val ;;
            layer6) l6=$val ;;
        esac
    done
    echo ""
    echo "===== 各层防护状态 ====="
    echo -n "  L1 blkdev_open:   "; [ "$l1" = "1" ] && echo -e "${G}已启用${N}" || echo -e "${Y}未启用${N}"
    echo -n "  L2 blkdev_write:  "; [ "$l2" = "1" ] && echo -e "${G}已启用${N}" || echo -e "${Y}未启用${N}"
    echo -n "  L3 blkdev_ioctl:  "; [ "$l3" = "1" ] && echo -e "${G}已启用${N}" || echo -e "${Y}未启用${N}"
    echo -n "  L4 syscall hook:  "; [ "$l4" = "1" ] && echo -e "${G}已启用${N}" || echo -e "${Y}未启用${N}"
    echo -n "  L5 内核自保:      "; [ "$l5" = "1" ] && echo -e "${G}已启用${N}" || echo -e "${Y}未启用${N}"
    echo -n "  L6 BIO兜底:       "; [ "$l6" = "1" ] && echo -e "${G}已启用${N}" || echo -e "${Y}未启用${N}"
    echo ""
}

# 导出日志
export_log() {
    local logfile="/data/local/tmp/tianji_lkm_log_$(date +%Y%m%d_%H%M%S).txt"
    echo "[+] 导出内核日志到 $logfile"
    dmesg | grep -i "tianji" > "$logfile" 2>/dev/null
    echo "[+] 最近20条日志:"
    dmesg | grep -i "tianji" | tail -20
    echo ""
    echo "[+] 完整日志已保存: $logfile"
}

# BIO层控制
bio_menu() {
    while true; do
        echo ""
        echo "===== 第六层 BIO控制 ====="
        echo "  1. 开启BIO防护"
        echo "  2. 关闭BIO防护"
        echo "  3. 设置userdata分区阈值"
        echo "  4. 白名单热重载"
        echo "  5. 返回"
        printf "  选择: "
        read -r opt
        case "$opt" in
            1) echo "B:1" > "$CTRL"; echo -e "${G}BIO防护已开启${N}" ;;
            2) echo "B:0" > "$CTRL"; echo -e "${Y}BIO防护已关闭${N}" ;;
            3) printf "输入分区阈值(1-255): "; read -r val; echo "P:$val" > "$CTRL"; echo "已设置为 $val" ;;
            4) echo "WL:R" > "$CTRL"; echo -e "${G}白名单缓存已重载${N}" ;;
            5) break ;;
        esac
    done
}

# 日志控制
log_menu() {
    echo ""
    echo "===== 日志控制 ====="
    echo "  0=关闭 1=关键 2=详细"
    printf "输入级别: "
    read -r lvl
    echo "L:$lvl" > "$CTRL"
    echo -e "${G}日志级别已设为 $lvl${N}"
}

# 主菜单
menu() {
    while true; do
        banner
        check_ver
        if is_loaded; then
            echo -e "  [${G}+${N}] 模块: 已加载"
        else
            echo -e "  [${Y}-${N}] 模块: 未加载"
        fi
        echo ""
        echo "  ===== 红米K60E MIUI14.0.6 ====="
        echo "  1. 加载模块 (insmod)"
        echo "  2. 卸载模块 (rmmod)"
        echo "  3. 开启全部防护"
        echo "  4. 关闭全部防护"
        echo "  5. 状态总览"
        echo "  6. 第六层BIO控制"
        echo "  7. 日志级别设置"
        echo "  8. 导出内核日志"
        echo "  9. 退出"
        echo ""
        printf "  请输入序号: "
        read -r choice
        case "$choice" in
            1) load_mod ;;
            2) unload_mod ;;
            3) protect_on ;;
            4) protect_off ;;
            5) show_status ;;
            6) bio_menu ;;
            7) log_menu ;;
            8) export_log ;;
            9) echo "退出"; break ;;
            *) echo -e "${R}无效选项${N}" ;;
        esac
        echo ""
        printf "按回车继续..."
        read -r dummy
    done
}

# 命令行模式
case "${1:-}" in
    load) check_root; load_mod ;;
    unload) check_root; unload_mod ;;
    on) check_root; protect_on ;;
    off) check_root; protect_off ;;
    status) show_status ;;
    log) export_log ;;
    *) check_root; menu ;;
esac
exit 0

