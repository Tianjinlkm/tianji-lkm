/*
 * 红米K60E MIUI14.0.6 机型配置头文件
 * config_device.h
 *
 * Device: Redmi K60E MIUI14.0.6 (codename: ruby)
 * Platform: MediaTek 天玑8200 (MT6896)
 * Kernel: Linux 5.10.168-android12
 * Android: 13 (MIUI 14.0.6)
 * BIO入口: submit_bio (generic_make_request已移除)
 *
 * 包含：K60E专属进程白名单 + 高危分区路径规则 + userdata分区阈值
 * 后续适配其他天玑机型，仅替换此文件，无需改动核心防护源码
 */

#ifndef CONFIG_DEVICE_H
#define CONFIG_DEVICE_H

/* ============================================================
 * 设备信息
 * ============================================================ */
#define TJ_DEVICE_NAME      "Redmi K60E MIUI14.0.6"
#define TJ_KERNEL_VERSION   "5.10"
#define TJ_PLATFORM         "MTK天玑8200"

/* ============================================================
 * userdata分区阈值
 * 红米K60E UFS设备userdata分区通常为分区号30+
 * 可通过控制命令 P:<num> 动态修改
 * ============================================================ */
#define TJ_USERDATA_PARTNO  30

/* ============================================================
 * 白名单结构体
 * comm: 进程名（max 16字节）
 * exe_base: 可执行文件名（用于exe路径匹配）
 * uids[4]: 允许的UID，{0}表示仅root，末尾0表示结束
 * ============================================================ */
typedef struct {
    const char *comm;
    const char *exe_base;
    const unsigned int uids[4];
} tj_wl_t;

/* ============================================================
 * 红米K60E MIUI14 专属系统进程白名单
 * 基于天玑8200平台 + MIUI14系统进程生成
 * 覆盖：基础守护、MTK基带、MTK安全、温控、性能、显示音频传感器等
 * ============================================================ */
static const tj_wl_t tj_wl_table[] = {
    /* 基础系统守护 */
    {"init",                          "init",                          {0}},
    {"ueventd",                       "init",                          {0}},
    {"vold",                          "vold",                          {0}},
    {"netd",                          "netd",                          {0}},
    {"installd",                      "installd",                      {0}},
    {"keystore",                      "keystore",                      {0}},
    {"gsid",                          "gsid",                            {0}},

    /* MTK基带/电话守护 */
    {"ccci_mdinit",                   "ccci_mdinit",                   {0,1001}},
    {"ccci_mdinit1",                  "ccci_mdinit1",                  {0,1001}},
    {"ccci_mdinit2",                  "ccci_mdinit2",                  {0,1001}},
    {"ccci_md34",                     "ccci_md34",                     {0,1001}},
    {"oemlogkit",                     "oemlogkit",                     {0,1000}},
    {"oem_rilproxy",                  "oem_rilproxy",                  {1001}},
    {"mtkfusion",                     "mtkfusion",                     {1001}},
    {"ril-daemon",                    "ril-daemon",                    {1001}},
    {"rild",                          "rild",                          {1001}},
    {"mobile_log_d",                  "mobile_log_d",                  {1000}},
    {"netdiag",                       "netdiag",                       {1000}},

    /* MTK安全域守护 */
    {"trustzone",                     "trustzone",                     {0}},
    {"mobicore",                      "mobicore",                      {0}},
    {"mobicore-700",                  "mobicore-700",                  {0}},
    {"tee",                           "tee",                           {0}},
    {"gatekeeperd",                   "gatekeeperd",                   {0}},

    /* MTK温控/性能守护 */
    {"thermal-engine",                "thermal-engine",                {0}},
    {"mi_thermald",                   "mi_thermald",                   {0}},
    {"perfd",                         "perfd",                         {0}},
    {"perf-hal",                      "perf-hal",                      {0}},
    {"powerkeeper",                   "powerkeeper",                   {0}},
    {"batterysaver",                  "batterysaver",                  {0}},
    {"miuibooster",                   "miuibooster",                   {0}},
    {"main_hook",                     "main_hook",                     {0}},

    /* MTK中断/子系统守护 */
    {"msm_irqbalance",                "msm_irqbalance",                {0,1000}},
    {"ssr_setup",                     "ssr_setup",                     {0,1000,1001}},
    {"ssr_diag",                      "ssr_diag",                      {0,1000,1001}},
    {"subsystem_ramdump",             "subsystem_ramdump",             {0}},

    /* MTK诊断守护 */
    {"diag-router",                   "diag-router",                   {1000}},
    {"diagcommd",                     "diagcommd",                     {1000}},
    {"diag_mdlog",                    "diag_mdlog",                    {1000}},

    /* 显示/图形守护 */
    {"vendor.qti.hardware.display.allocator-service", "display-alloc", {0}},
    {"vendor.qti.hardware.display.composer-service", "display-composer",{0}},
    {"gralloc-service",               "gralloc-service",               {0}},
    {"surfaceflinger",                "surfaceflinger",                {0}},

    /* 音频守护 */
    {"audio-hal-2-0",                 "audio-hal-2-0",                 {0}},
    {"sound_trigger_3",               "sound_trigger_3",               {0}},
    {"audioserver",                   "audioserver",                   {0}},

    /* 传感器守护 */
    {"sensors.qti",                   "sensors.qti",                   {0}},
    {"adsprpcd",                      "adsprpcd",                      {0}},
    {"adsprpcd-sensor",               "adsprpcd-sensor",               {0}},

    /* GPS/位置守护 */
    {"loc_hal",                       "loc_hal",                       {0}},
    {"vendor.qti.gnss@4.0-service",   "gnss-service",                  {0}},
    {"xtwifi-client",                 "xtwifi-client",                 {0}},

    /* 充电/电源守护 */
    {"chargehub",                     "chargehub",                     {0}},
    {"healthd",                       "healthd",                       {0}},
    {"batteryd",                      "batteryd",                      {0}},

    /* WiFi/蓝牙守护 */
    {"wpa_supplicant",                "wpa_supplicant",                {0,1010}},
    {"hostapd",                       "hostapd",                       {0}},
    {"bluetooth-1-0",                 "bluetooth-1-0",                 {0,1002}},
    {"android.hardware.bluetooth@1.0-service", "bt-service",          {0,1002}},

    /* 相机守护 */
    {"cameraserver",                  "cameraserver",                  {0}},
    {"vendor.qti.hardware.camera.device@3.0-service", "camera-service",{0}},

    /* 小米/红米专属守护 */
    {"MI_RIC",                        "MI_RIC",                        {0}},
    {"mab",                           "mab",                           {0}},
    {"msa",                           "msa",                           {0}},
    {"mi_connect_service",            "mi_connect_service",            {0}},
    {"miui-wallpaper",                "miui-wallpaper",                {0}},
    {"system_server",                 "system_server",                 {1000}},
    {"app_process",                   "app_process",                   {0}},
    {"zygote",                        "zygote",                        {0}},
    {"zygote64",                      "zygote64",                      {0}},
};

/* 白名单条目数（自动计算） */
#define WLCNT (int)(sizeof(tj_wl_table)/sizeof(tj_wl_table[0]))

/* ============================================================
 * 高危分区路径规则（openat拦截）
 * prefix: 路径前缀（max 28字节）
 * len: 前缀长度
 * ============================================================ */
typedef struct {
    const char *prefix;
    unsigned char len;
} tj_open_rule_t;

static const tj_open_rule_t tj_open_rules[] = {
    {"/dev/block",          10},  /* 块设备节点 */
    {"/dev/ufs-bsg",        12},  /* UFS BSG设备 */
    {"/dev/bsg",            8},   /* BSG设备 */
    {"/dev/sg",             7},   /* SCSI通用设备 */
    {"/proc/sysrq-trigger", 20},  /* 系统请求触发 */
    {"/sys/class/android_usb", 22}, /* USB配置 */
    {"/dev/socket/prop",    16},  /* 属性socket */
    {"/data/adb/kpatch",    16},  /* KernelPatch写入 */
};

#define TJ_OPEN_RULES_CNT (int)(sizeof(tj_open_rules)/sizeof(tj_open_rules[0]))

#endif /* CONFIG_DEVICE_H */
